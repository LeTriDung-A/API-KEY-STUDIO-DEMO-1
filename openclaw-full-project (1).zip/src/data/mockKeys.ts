import { ApiKey, ApiEndpoint } from '../types/apiKey';

export const INITIAL_MOCK_KEYS: ApiKey[] = [
  {
    id: 'key_prod_01j7x9k2p',
    name: 'Production Payment Processor',
    keyPrefix: 'sk_live_',
    maskedKey: 'sk_live_9f8b••••••••••••••••3a9d',
    hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    tail: '3a9d',
    environment: 'production',
    scopes: ['read:users', 'read:data', 'billing:manage', 'webhooks:listen'],
    createdAt: new Date(Date.now() - 14 * 86400000).toISOString(),
    expiresAt: new Date(Date.now() + 76 * 86400000).toISOString(),
    lastUsedAt: new Date(Date.now() - 320000).toISOString(),
    rateLimit: {
      requestsPerMinute: 300,
      requestsPerDay: 50000,
    },
    allowedIps: ['198.51.100.4/32', '203.0.113.0/24'],
    status: 'active',
    requestCount: 14892,
  },
  {
    id: 'key_test_02k8y0l3q',
    name: 'Mobile iOS Integration Test',
    keyPrefix: 'sk_test_',
    maskedKey: 'sk_test_7a1e••••••••••••••••8c2f',
    hash: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
    tail: '8c2f',
    environment: 'development',
    scopes: ['read:users', 'read:data', 'write:records'],
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    expiresAt: null, // Never expires
    lastUsedAt: new Date(Date.now() - 42000).toISOString(),
    rateLimit: {
      requestsPerMinute: 60,
      requestsPerDay: 5000,
    },
    allowedIps: [],
    status: 'active',
    requestCount: 3410,
  },
  {
    id: 'key_stg_03l9z1m4r',
    name: 'Staging Analytics Pipeline',
    keyPrefix: 'sk_test_',
    maskedKey: 'sk_test_4c2d••••••••••••••••6e1a',
    hash: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    tail: '6e1a',
    environment: 'staging',
    scopes: ['read:analytics', 'read:data'],
    createdAt: new Date(Date.now() - 88 * 86400000).toISOString(),
    expiresAt: new Date(Date.now() + 2 * 86400000).toISOString(), // Expiring in 2 days
    lastUsedAt: new Date(Date.now() - 8600000).toISOString(),
    rateLimit: {
      requestsPerMinute: 120,
      requestsPerDay: 20000,
    },
    allowedIps: [],
    status: 'expiring_soon',
    requestCount: 8940,
  },
];

export const MOCK_API_ENDPOINTS: ApiEndpoint[] = [
  {
    id: 'auth_verify',
    method: 'GET',
    path: '/v1/auth/verify',
    description: 'Verify API key status, entropy verification, and list assigned scopes',
    requiredScopes: [],
    mockResponse: (key: ApiKey | null): { status: number; data: any; headers?: Record<string, string> } => {
      if (!key) {
        return {
          status: 401,
          data: {
            error: {
              code: 'unauthorized',
              message: 'Invalid or missing API key in Authorization: Bearer header.',
              documentation_url: 'https://docs.example.com/api/errors#unauthorized',
            },
          },
          headers: { 'WWW-Authenticate': 'Bearer error="invalid_token"' },
        };
      }
      return {
        status: 200,
        data: {
          authenticated: true,
          key_id: key.id,
          key_name: key.name,
          environment: key.environment,
          masked_key: key.maskedKey,
          granted_scopes: key.scopes,
          rate_limit: {
            limit_per_minute: key.rateLimit.requestsPerMinute,
            remaining_per_minute: Math.max(1, key.rateLimit.requestsPerMinute - 3),
            reset_seconds: 48,
          },
          expires_at: key.expiresAt,
          status: key.status,
        },
        headers: {
          'Content-Type': 'application/json',
          'X-RateLimit-Limit': key.rateLimit.requestsPerMinute.toString(),
          'X-RateLimit-Remaining': (key.rateLimit.requestsPerMinute - 3).toString(),
          'X-RateLimit-Reset': '48',
        },
      };
    },
  },
  {
    id: 'users_list',
    method: 'GET',
    path: '/v1/users',
    description: 'Query active user directories and metadata',
    requiredScopes: ['read:users'],
    mockResponse: (key: ApiKey | null): { status: number; data: any; headers?: Record<string, string> } => {
      if (!key) {
        return {
          status: 401,
          data: { error: { code: 'unauthorized', message: 'Missing Authorization header.' } },
          headers: {},
        };
      }
      if (!key.scopes.includes('read:users') && !key.scopes.includes('admin:all')) {
        return {
          status: 403,
          data: {
            error: {
              code: 'insufficient_scope',
              message: 'The token does not possess the required "read:users" scope.',
              required_scopes: ['read:users'],
              provided_scopes: key.scopes,
            },
          },
          headers: { 'X-OAuth-Scopes-Required': 'read:users' },
        };
      }
      return {
        status: 200,
        data: {
          object: 'list',
          data: [
            { id: 'usr_81a', name: 'Elena Rostova', role: 'Security Architect', status: 'active', email: 'elena@corp.net' },
            { id: 'usr_82b', name: 'Marcus Vance', role: 'Lead DevOps', status: 'active', email: 'marcus@corp.net' },
            { id: 'usr_83c', name: 'Tara Chen', role: 'Data Scientist', status: 'active', email: 'tara@corp.net' },
          ],
          has_more: false,
          total_count: 3,
        },
        headers: {
          'Content-Type': 'application/json',
          'X-RateLimit-Remaining': (key.rateLimit.requestsPerMinute - 4).toString(),
        },
      };
    },
  },
  {
    id: 'records_create',
    method: 'POST',
    path: '/v1/records',
    description: 'Insert new structured event or telemetry record',
    requiredScopes: ['write:records'],
    mockResponse: (key: ApiKey | null, requestBody?: any): { status: number; data: any; headers?: Record<string, string> } => {
      if (!key) {
        return {
          status: 401,
          data: { error: { code: 'unauthorized', message: 'Missing Authorization header.' } },
          headers: {},
        };
      }
      if (!key.scopes.includes('write:records') && !key.scopes.includes('admin:all')) {
        return {
          status: 403,
          data: {
            error: {
              code: 'insufficient_scope',
              message: 'Key lacks "write:records" permission.',
              required_scopes: ['write:records'],
            },
          },
          headers: {},
        };
      }
      return {
        status: 201,
        data: {
          id: `rec_${Math.random().toString(36).substring(2, 9)}`,
          status: 'created',
          payload: requestBody || { title: 'Telemetry Batch', count: 120 },
          created_at: new Date().toISOString(),
          processed_by: key.name,
        },
        headers: {
          'Content-Type': 'application/json',
          'Location': '/v1/records/rec_new',
        },
      };
    },
  },
  {
    id: 'billing_invoices',
    method: 'GET',
    path: '/v1/billing/invoices',
    description: 'Retrieve pending or settled customer invoices',
    requiredScopes: ['billing:manage'],
    mockResponse: (key: ApiKey | null): { status: number; data: any; headers?: Record<string, string> } => {
      if (!key) {
        return {
          status: 401,
          data: { error: { code: 'unauthorized', message: 'Missing Authorization header.' } },
          headers: {},
        };
      }
      if (!key.scopes.includes('billing:manage') && !key.scopes.includes('admin:all')) {
        return {
          status: 403,
          data: {
            error: {
              code: 'insufficient_scope',
              message: 'Requires "billing:manage" scope for commercial billing endpoints.',
              required_scopes: ['billing:manage'],
            },
          },
          headers: {},
        };
      }
      return {
        status: 200,
        data: {
          invoices: [
            { id: 'inv_2026_01', amount: 4800.00, currency: 'USD', status: 'paid', period: 'October 2026' },
            { id: 'inv_2026_02', amount: 5240.50, currency: 'USD', status: 'draft', period: 'November 2026' },
          ],
        },
        headers: { 'Content-Type': 'application/json' },
      };
    },
  },
  {
    id: 'records_delete',
    method: 'DELETE',
    path: '/v1/records/rec_purge',
    description: 'Purge existing data record permanently',
    requiredScopes: ['delete:records'],
    mockResponse: (key: ApiKey | null): { status: number; data: any; headers?: Record<string, string> } => {
      if (!key) {
        return {
          status: 401,
          data: { error: { code: 'unauthorized', message: 'Missing Authorization header.' } },
          headers: {},
        };
      }
      if (!key.scopes.includes('delete:records') && !key.scopes.includes('admin:all')) {
        return {
          status: 403,
          data: {
            error: {
              code: 'insufficient_scope',
              message: 'Requires "delete:records" scope.',
              required_scopes: ['delete:records'],
            },
          },
          headers: {},
        };
      }
      return {
        status: 200,
        data: {
          deleted: true,
          target_id: 'rec_purge',
          purged_at: new Date().toISOString(),
        },
        headers: { 'Content-Type': 'application/json' },
      };
    },
  },
];
