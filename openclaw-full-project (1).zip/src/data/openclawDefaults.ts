import { WorkspaceFiles } from '../types/openclaw';

export const DEFAULT_WORKSPACE_FILES: WorkspaceFiles = {
  'SOUL.md': `# SOUL.md - Bản sắc Agent OpenClaw (Agent Persona)

- **Tên (Name):** OpenClaw Local Assistant
- **Vai trò (Role):** Trợ lý AI tự trị chạy trực tiếp trên máy cục bộ hoặc máy chủ riêng (Self-hosted Autonomous Agent).
- **Nguyên tắc hành động (Directives):**
  1. Hỗ trợ nhà phát triển tự động hóa các tác vụ lập trình, quản lý file, thực thi lệnh shell an toàn.
  2. Luôn ghi nhớ thông tin dài hạn quan trọng vào \`MEMORY.md\` khi người dùng chia sẻ sở thích hoặc dữ liệu dự án.
  3. Giao tiếp tự nhiên, ngắn gọn và hữu ích bằng ngôn ngữ của người dùng (Tiếng Việt hoặc Tiếng Anh).
  4. Tự kiểm tra kết quả lệnh bash và nội dung file trước khi hoàn tất phản hồi.
`,

  'MEMORY.md': `# MEMORY.md - Bộ nhớ dài hạn (Long-Term Memory)

*Các thông tin được tự động lưu lại qua các phiên chat:*
- **User:** clan41857 (Developer)
- **Tech Stack:** TypeScript, React 19, Tailwind CSS v4, Express backend
- **Ưu tiên:** Tạo và quản lý API Key an toàn, mã hóa SHA-256, kiểm tra checksum CRC32
- **Dự án hiện tại:** OpenClaw Interactive Web Demo & API Key Studio
`,

  'TOOLS.md': `# TOOLS.md - Danh mục Công cụ & Quyền hạn (MCP & Tools)

- **bash:** Thực thi câu lệnh shell trong môi trường sandbox cô lập.
- **file_read:** Đọc nội dung file từ thư mục làm việc /workspace.
- **file_write:** Tạo mới hoặc cập nhật nội dung file mã nguồn, markdown.
- **memory_save:** Cập nhật mục mới vào file MEMORY.md vĩnh viễn.
- **web_search:** Tra cứu tài liệu và tin tức kỹ thuật trực tuyến.
`,

  'USER.md': `# USER.md - Hồ sơ Người dùng (Developer Profile)

- **Tên:** Developer / User
- **Email:** clan41857@gmail.com
- **Môi trường:** AI Studio Web Environment & Local Workstation
- **Ngôn ngữ ưa thích:** Tiếng Việt / English
`,

  'openclaw.json': `{
  "name": "openclaw-gateway",
  "version": "1.0.0",
  "gateway": {
    "port": 18789,
    "host": "127.0.0.1",
    "auth": {
      "mode": "bearer_token",
      "token_prefix": "claw_"
    }
  },
  "channels": {
    "web": { "enabled": true },
    "telegram": { "enabled": true, "bot_username": "@openclaw_demo_bot" },
    "whatsapp": { "enabled": true },
    "discord": { "enabled": true }
  },
  "default_model": "gemini-3.8-flash",
  "workspace_root": "/workspace"
}
`,

  'src/index.js': `// Workspace file created by OpenClaw
console.log("Hello from OpenClaw autonomous workspace!");
`,
};

export interface DemoScenario {
  id: string;
  title: string;
  prompt: string;
  description: string;
  category: 'memory' | 'code' | 'system' | 'web';
  expectedTool: string;
}

export const DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'demo-memory',
    title: 'Ghi nhớ sở thích vào MEMORY.md',
    prompt: 'Tôi thường viết backend bằng Express và thích mã hóa API Key với SHA-256. Hãy ghi nhớ điều này vào MEMORY.md cho tôi.',
    description: 'Agent đọc bối cảnh, kích hoạt tool memory_save và cập nhật MEMORY.md',
    category: 'memory',
    expectedTool: 'memory_save',
  },
  {
    id: 'demo-code',
    title: 'Quét thư mục & Viết mã nguồn',
    prompt: 'Hãy kiểm tra các file hiện có bằng lệnh bash, sau đó tạo một file script src/utils/keygen.js để tạo API key ngẫu nhiên.',
    description: 'Agent chạy lệnh bash ls, phân tích cấu trúc và dùng file_write để tạo mã nguồn',
    category: 'code',
    expectedTool: 'file_write',
  },
  {
    id: 'demo-system',
    title: 'Kiểm tra hệ sinh thái (System Check)',
    prompt: 'Chạy lệnh kiểm tra phiên bản Node.js, trạng thái RAM và cấu hình gateway trong openclaw.json.',
    description: 'Agent chạy chuỗi lệnh chẩn đoán hệ thống an toàn và đọc cấu hình gateway',
    category: 'system',
    expectedTool: 'bash',
  },
  {
    id: 'demo-api-key',
    title: 'Tích hợp & Kiểm tra API Key',
    prompt: 'Tạo một cấu hình .env chứa GEMINI_API_KEY và kiểm tra định dạng key có hợp lệ không.',
    description: 'Agent tạo file môi trường và xác thực entropy của API Key',
    category: 'code',
    expectedTool: 'file_write',
  },
];
