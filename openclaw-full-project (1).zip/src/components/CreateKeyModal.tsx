import React, { useState } from 'react';
import { X, KeyRound, Shield, AlertCircle, CheckSquare, Square, Sliders, Globe } from 'lucide-react';
import { ApiKey, KeyEnvironment } from '../types/apiKey';
import { AVAILABLE_SCOPES, generateCryptographicKey } from '../utils/crypto';

interface CreateKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeyCreated: (newKey: ApiKey, rawPlaintextKey: string) => void;
}

export const CreateKeyModal: React.FC<CreateKeyModalProps> = ({ isOpen, onClose, onKeyCreated }) => {
  const [name, setName] = useState('');
  const [environment, setEnvironment] = useState<KeyEnvironment>('production');
  const [prefixType, setPrefixType] = useState<'standard' | 'custom'>('standard');
  const [customPrefix, setCustomPrefix] = useState('ak_');
  const [byteEntropy, setByteEntropy] = useState<number>(24);
  const [includeChecksum, setIncludeChecksum] = useState(true);
  const [expiryOption, setExpiryOption] = useState<'never' | '7' | '30' | '90' | '365' | 'custom'>('30');
  const [customExpiryDate, setCustomExpiryDate] = useState('');
  const [selectedScopes, setSelectedScopes] = useState<string[]>([
    'read:users',
    'read:data',
    'write:records',
  ]);
  const [rateLimitPerMinute, setRateLimitPerMinute] = useState<number>(120);
  const [ipAllowlist, setIpAllowlist] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const getPrefix = () => {
    if (prefixType === 'custom') {
      return customPrefix.endsWith('_') ? customPrefix : `${customPrefix}_`;
    }
    if (environment === 'production') return 'sk_live_';
    if (environment === 'staging') return 'sk_stg_';
    return 'sk_test_';
  };

  const handleSelectAllScopes = () => {
    setSelectedScopes(AVAILABLE_SCOPES.map(s => s.id));
  };

  const handleReadOnlyScopes = () => {
    setSelectedScopes(AVAILABLE_SCOPES.filter(s => s.category === 'Read').map(s => s.id));
  };

  const handleClearScopes = () => {
    setSelectedScopes([]);
  };

  const toggleScope = (scopeId: string) => {
    setSelectedScopes(prev =>
      prev.includes(scopeId) ? prev.filter(id => id !== scopeId) : [...prev, scopeId]
    );
  };

  const calculateExpiryTimestamp = (): string | null => {
    if (expiryOption === 'never') return null;
    if (expiryOption === 'custom') {
      return customExpiryDate ? new Date(customExpiryDate).toISOString() : null;
    }
    const days = parseInt(expiryOption, 10);
    return new Date(Date.now() + days * 86400000).toISOString();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Please provide a name or description for this API key.');
      return;
    }

    if (selectedScopes.length === 0) {
      setError('Select at least one scope to grant this API key permissions.');
      return;
    }

    setIsSubmitting(true);

    try {
      const prefix = getPrefix();
      const generated = await generateCryptographicKey({
        prefix,
        byteEntropy,
        includeChecksum,
      });

      const expiresAt = calculateExpiryTimestamp();
      const ips = ipAllowlist
        .split('\n')
        .map(ip => ip.trim())
        .filter(Boolean);

      const newApiKey: ApiKey = {
        id: `key_${Math.random().toString(36).substring(2, 11)}`,
        name: name.trim(),
        keyPrefix: prefix,
        maskedKey: generated.maskedKey,
        hash: generated.hash,
        tail: generated.tail,
        environment,
        scopes: selectedScopes,
        createdAt: new Date().toISOString(),
        expiresAt,
        lastUsedAt: null,
        rateLimit: {
          requestsPerMinute: rateLimitPerMinute,
          requestsPerDay: rateLimitPerMinute * 60 * 12,
        },
        allowedIps: ips,
        status: 'active',
        requestCount: 0,
      };

      onKeyCreated(newApiKey, generated.fullKey);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to generate cryptographic key.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-zinc-100">Create API Key</h2>
              <p className="text-xs text-zinc-400">Configure cryptographic parameters and permission scopes</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-200 p-1 rounded-lg hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="flex items-center gap-2 p-3 text-xs text-rose-300 bg-rose-500/10 border border-rose-500/20 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Key Name */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
              Key Name / Purpose *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Billing Sync Worker, iOS App Staging, Analytics Ingest"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3.5 py-2 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all"
              required
            />
          </div>

          {/* Environment & Prefix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                Target Environment
              </label>
              <div className="flex items-center p-1 bg-zinc-950 border border-zinc-800 rounded-lg">
                {(['production', 'staging', 'development'] as KeyEnvironment[]).map((env) => (
                  <button
                    key={env}
                    type="button"
                    onClick={() => setEnvironment(env)}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md capitalize transition-colors ${
                      environment === env
                        ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {env}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                Key Prefix Format
              </label>
              <div className="flex items-center gap-2">
                <select
                  value={prefixType}
                  onChange={(e) => setPrefixType(e.target.value as any)}
                  className="bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="standard">Standard ({getPrefix()})</option>
                  <option value="custom">Custom Prefix</option>
                </select>
                {prefixType === 'custom' && (
                  <input
                    type="text"
                    value={customPrefix}
                    onChange={(e) => setCustomPrefix(e.target.value)}
                    placeholder="e.g. app_"
                    className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-2 text-xs text-zinc-100 font-mono focus:outline-none focus:border-amber-400"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Security & Entropy Configuration */}
          <div className="p-3.5 bg-zinc-950/70 border border-zinc-800/80 rounded-xl space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-zinc-300">
              <span className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                Cryptographic Entropy & Verification
              </span>
              <span className="text-zinc-500 font-mono text-[11px]">{byteEntropy * 8} bits</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { bytes: 16, label: '128-bit', desc: 'Standard' },
                { bytes: 24, label: '192-bit', desc: 'Recommended' },
                { bytes: 32, label: '256-bit', desc: 'High Security' },
              ].map((item) => (
                <button
                  key={item.bytes}
                  type="button"
                  onClick={() => setByteEntropy(item.bytes)}
                  className={`p-2 rounded-lg border text-left transition-all ${
                    byteEntropy === item.bytes
                      ? 'border-amber-400/50 bg-amber-400/5 text-zinc-100'
                      : 'border-zinc-800 hover:border-zinc-700 text-zinc-400'
                  }`}
                >
                  <div className="text-xs font-medium text-zinc-200">{item.label}</div>
                  <div className="text-[10px] text-zinc-500">{item.desc}</div>
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-zinc-800/60 text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-zinc-300 select-none">
                <input
                  type="checkbox"
                  checked={includeChecksum}
                  onChange={(e) => setIncludeChecksum(e.target.checked)}
                  className="rounded border-zinc-700 bg-zinc-900 text-amber-500 focus:ring-0"
                />
                <span>Include CRC32 Checksum suffix (GitHub secret scan verification)</span>
              </label>
            </div>
          </div>

          {/* Expiration Settings */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
              Expiration Policy
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[
                { id: '7', label: '7 Days' },
                { id: '30', label: '30 Days' },
                { id: '90', label: '90 Days' },
                { id: '365', label: '1 Year' },
                { id: 'never', label: 'Never' },
                { id: 'custom', label: 'Custom' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setExpiryOption(opt.id as any)}
                  className={`py-1.5 px-2 rounded-lg border text-xs font-medium text-center transition-all ${
                    expiryOption === opt.id
                      ? 'border-amber-400/50 bg-amber-400/10 text-amber-300'
                      : 'border-zinc-800 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {expiryOption === 'custom' && (
              <div className="mt-2.5">
                <input
                  type="date"
                  value={customExpiryDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setCustomExpiryDate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-100 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}
          </div>

          {/* Scope Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-zinc-300 uppercase tracking-wider">
                Permission Scopes ({selectedScopes.length} selected)
              </label>
              <div className="flex items-center gap-2 text-xs">
                <button
                  type="button"
                  onClick={handleSelectAllScopes}
                  className="text-amber-400 hover:text-amber-300 transition-colors"
                >
                  Select All
                </button>
                <span className="text-zinc-600">·</span>
                <button
                  type="button"
                  onClick={handleReadOnlyScopes}
                  className="text-zinc-400 hover:text-zinc-200 transition-colors"
                >
                  Read Only
                </button>
                <span className="text-zinc-600">·</span>
                <button
                  type="button"
                  onClick={handleClearScopes}
                  className="text-zinc-400 hover:text-zinc-200 transition-colors"
                >
                  Clear
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 border border-zinc-800 rounded-xl bg-zinc-950/40">
              {AVAILABLE_SCOPES.map((scope) => {
                const isChecked = selectedScopes.includes(scope.id);
                return (
                  <div
                    key={scope.id}
                    onClick={() => toggleScope(scope.id)}
                    className={`flex items-start gap-2.5 p-2 rounded-lg cursor-pointer border transition-colors select-none ${
                      isChecked
                        ? 'border-amber-400/30 bg-amber-400/5'
                        : 'border-transparent hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="mt-0.5 text-amber-400">
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 fill-amber-400/20" />
                      ) : (
                        <Square className="w-4 h-4 text-zinc-600" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-mono font-medium text-zinc-200">{scope.id}</span>
                        <span className="text-[10px] text-zinc-500 font-sans">({scope.category})</span>
                      </div>
                      <p className="text-[11px] text-zinc-400 truncate">{scope.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Rate Limit & IP Allowlist (Advanced) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-zinc-800/80">
            <div>
              <label className="flex items-center gap-1 text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                <Sliders className="w-3.5 h-3.5 text-zinc-400" />
                Rate Limit (Req / Min)
              </label>
              <select
                value={rateLimitPerMinute}
                onChange={(e) => setRateLimitPerMinute(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                <option value={30}>30 req/min (Low volume)</option>
                <option value={60}>60 req/min (Standard client)</option>
                <option value={120}>120 req/min (Standard backend)</option>
                <option value={300}>300 req/min (High throughput)</option>
                <option value={1000}>1,000 req/min (Unrestricted cluster)</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-1 text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                <Globe className="w-3.5 h-3.5 text-zinc-400" />
                IP Restrictions (Optional)
              </label>
              <input
                type="text"
                value={ipAllowlist}
                onChange={(e) => setIpAllowlist(e.target.value)}
                placeholder="e.g. 192.168.1.1/32, 10.0.0.0/16"
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-lg shadow-sm transition-all disabled:opacity-50"
            >
              <KeyRound className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>{isSubmitting ? 'Generating...' : 'Generate API Key'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
