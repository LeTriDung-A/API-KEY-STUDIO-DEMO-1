import React from 'react';
import { ApiKey } from '../types/apiKey';
import { AVAILABLE_SCOPES } from '../utils/crypto';
import { X, KeyRound, Shield, Clock, Globe, Sliders, Hash, Activity } from 'lucide-react';

interface KeyDetailsDrawerProps {
  apiKey: ApiKey | null;
  onClose: () => void;
  onTestKey: (key: ApiKey) => void;
}

export const KeyDetailsDrawer: React.FC<KeyDetailsDrawerProps> = ({
  apiKey,
  onClose,
  onTestKey,
}) => {
  if (!apiKey) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-md h-full bg-zinc-900 border-l border-zinc-800 p-6 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-200">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-400/10 flex items-center justify-center text-amber-400">
                <KeyRound className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-zinc-100">{apiKey.name}</h3>
                <span className="text-xs text-zinc-500 font-mono">{apiKey.id}</span>
              </div>
            </div>
            <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200 p-1">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Key Identifier */}
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1">
            <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-medium">Masked Token</span>
            <div className="font-mono text-xs text-amber-300 break-all select-all">{apiKey.maskedKey}</div>
          </div>

          {/* Security & Hashing */}
          <div className="space-y-2">
            <span className="text-xs font-medium text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-zinc-500" />
              Cryptographic Integrity
            </span>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2 text-xs">
              <div>
                <div className="text-[10px] text-zinc-500">SHA-256 Digest (DB Storage Representation)</div>
                <div className="font-mono text-[11px] text-zinc-400 break-all select-all mt-0.5">{apiKey.hash}</div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-zinc-800/80 text-[11px] text-zinc-400">
                <span>Entropy Rating:</span>
                <span className="text-emerald-400 font-mono font-medium">192-bit (CSPRNG)</span>
              </div>
            </div>
          </div>

          {/* Scopes */}
          <div className="space-y-2">
            <span className="text-xs font-medium text-zinc-400 uppercase tracking-wider">
              Granted Permissions ({apiKey.scopes.length})
            </span>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {apiKey.scopes.map((s) => {
                const def = AVAILABLE_SCOPES.find((sc) => sc.id === s);
                return (
                  <div key={s} className="p-2 bg-zinc-950 border border-zinc-800/80 rounded-lg text-xs">
                    <div className="font-mono text-zinc-200 font-medium">{s}</div>
                    {def && <div className="text-[11px] text-zinc-500">{def.description}</div>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Limits & Network */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
              <div className="text-[10px] uppercase text-zinc-500 flex items-center gap-1">
                <Sliders className="w-3 h-3" /> Rate Limit
              </div>
              <div className="font-mono text-zinc-200 mt-1">{apiKey.rateLimit.requestsPerMinute} req/min</div>
            </div>
            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
              <div className="text-[10px] uppercase text-zinc-500 flex items-center gap-1">
                <Activity className="w-3 h-3" /> Requests
              </div>
              <div className="font-mono text-zinc-200 mt-1">{apiKey.requestCount.toLocaleString()} total</div>
            </div>
          </div>

          {/* Dates */}
          <div className="text-xs text-zinc-400 space-y-1 border-t border-zinc-800 pt-3">
            <div className="flex justify-between">
              <span>Created At:</span>
              <span className="text-zinc-200">{new Date(apiKey.createdAt).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Expires At:</span>
              <span className="text-zinc-200">
                {apiKey.expiresAt ? new Date(apiKey.expiresAt).toLocaleDateString() : 'Never'}
              </span>
            </div>
          </div>
        </div>

        {/* Footer action */}
        <div className="pt-4 border-t border-zinc-800">
          <button
            onClick={() => {
              onTestKey(apiKey);
              onClose();
            }}
            className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-zinc-950 font-semibold text-xs rounded-xl shadow-md transition-colors"
          >
            Open in API Sandbox
          </button>
        </div>
      </div>
    </div>
  );
};
