import React, { useState } from 'react';
import { ApiKey } from '../types/apiKey';
import { Check, Copy, Eye, EyeOff, Download, AlertTriangle, ShieldCheck } from 'lucide-react';

interface KeyRevealModalProps {
  isOpen: boolean;
  apiKey: ApiKey | null;
  rawKey: string;
  onClose: () => void;
  onCopySuccess: () => void;
}

export const KeyRevealModal: React.FC<KeyRevealModalProps> = ({
  isOpen,
  apiKey,
  rawKey,
  onClose,
  onCopySuccess,
}) => {
  const [isRevealed, setIsRevealed] = useState(true);
  const [copied, setCopied] = useState(false);

  if (!isOpen || !apiKey) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(rawKey);
      setCopied(true);
      onCopySuccess();
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = rawKey;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      onCopySuccess();
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleDownloadEnv = () => {
    const envContent = `# API Credentials for ${apiKey.name}\n# Generated: ${new Date().toISOString()}\nAPI_KEY="${rawKey}"\nAPI_ENVIRONMENT="${apiKey.environment}"\nAPI_KEY_ID="${apiKey.id}"\n`;
    const blob = new Blob([envContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `.env.${apiKey.environment}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const jsonContent = JSON.stringify(
      {
        id: apiKey.id,
        name: apiKey.name,
        apiKey: rawKey,
        environment: apiKey.environment,
        scopes: apiKey.scopes,
        createdAt: apiKey.createdAt,
        expiresAt: apiKey.expiresAt,
      },
      null,
      2
    );
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `credentials-${apiKey.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Banner */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-6 py-3.5 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-200/90 leading-relaxed">
            <span className="font-semibold text-amber-300">Save this secret key now.</span> For security reasons, we do not store plaintext keys and you will not be able to view it again.
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Key Title & Meta */}
          <div>
            <div className="flex items-center gap-2 text-xs text-zinc-400 mb-1">
              <span>{apiKey.environment.toUpperCase()} KEY</span>
              <span aria-hidden="true">·</span>
              <span>{apiKey.scopes.length} Scopes</span>
              <span aria-hidden="true">·</span>
              <span>Expires {apiKey.expiresAt ? new Date(apiKey.expiresAt).toLocaleDateString() : 'Never'}</span>
            </div>
            <h3 className="text-lg font-semibold text-zinc-100">{apiKey.name}</h3>
          </div>

          {/* Key Display & 1-Click Copy */}
          <div className="space-y-2">
            <label className="block text-xs font-medium text-zinc-400 uppercase tracking-wider">
              Secret API Key (Plaintext)
            </label>
            <div className="flex items-center gap-2 p-2 bg-zinc-950 border border-zinc-800 rounded-xl">
              <input
                type={isRevealed ? 'text' : 'password'}
                readOnly
                value={rawKey}
                className="flex-1 bg-transparent border-0 px-2.5 py-1.5 text-sm font-mono text-amber-300 select-all focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setIsRevealed(!isRevealed)}
                className="p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80 rounded-lg transition-colors"
                title={isRevealed ? 'Hide secret' : 'Show secret'}
              >
                {isRevealed ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={handleCopy}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                  copied
                    ? 'bg-emerald-500 text-zinc-950 font-bold'
                    : 'bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-zinc-950 shadow-md'
                }`}
              >
                {copied ? <Check className="w-4 h-4 stroke-[3]" /> : <Copy className="w-4 h-4 stroke-[2.5]" />}
                <span>{copied ? 'Copied!' : 'Copy Key'}</span>
              </button>
            </div>
          </div>

          {/* Download Options */}
          <div className="flex flex-wrap items-center gap-2.5 pt-2">
            <button
              onClick={handleDownloadEnv}
              className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>Download .env file</span>
            </button>
            <button
              onClick={handleDownloadJson}
              className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/60 rounded-lg transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>Download JSON credentials</span>
            </button>
          </div>

          {/* Security Notice Checklist */}
          <div className="p-3.5 bg-zinc-950/80 border border-zinc-800/60 rounded-xl space-y-2 text-xs text-zinc-400">
            <div className="flex items-center gap-2 text-zinc-300 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Cryptographic Integrity</span>
            </div>
            <div className="font-mono text-[11px] text-zinc-500 break-all">
              SHA-256 Hash: {apiKey.hash}
            </div>
          </div>

          {/* Footer Action */}
          <div className="flex items-center justify-end pt-4 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 text-xs font-semibold text-zinc-950 bg-zinc-100 hover:bg-white active:bg-zinc-200 rounded-lg shadow-sm transition-all"
            >
              I Have Saved My Secret Key
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
