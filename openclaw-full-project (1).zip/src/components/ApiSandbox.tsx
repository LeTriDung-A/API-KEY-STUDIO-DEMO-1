import React, { useState } from 'react';
import { ApiKey, ApiEndpoint, TestExecutionResult } from '../types/apiKey';
import { MOCK_API_ENDPOINTS } from '../data/mockKeys';
import { Play, Copy, Check, Terminal, Shield, ArrowRight, RefreshCw, Send } from 'lucide-react';

interface ApiSandboxProps {
  keys: ApiKey[];
  selectedKeyId?: string;
  onRecordRequest: (keyId: string) => void;
  onToast: (title: string, message?: string) => void;
}

export const ApiSandbox: React.FC<ApiSandboxProps> = ({
  keys,
  selectedKeyId,
  onRecordRequest,
  onToast,
}) => {
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>('auth_verify');
  const [currentKeyId, setCurrentKeyId] = useState<string>(selectedKeyId || (keys[0]?.id || ''));
  const [customKeyOverride, setCustomKeyOverride] = useState('');
  const [requestBodyText, setRequestBodyText] = useState('{\n  "title": "Production Deployment",\n  "service": "api-gateway",\n  "status": "ready"\n}');
  const [isLoading, setIsLoading] = useState(false);
  const [lastResult, setLastResult] = useState<TestExecutionResult | null>(null);
  const [activeResponseTab, setActiveResponseTab] = useState<'body' | 'headers'>('body');
  const [copiedResponse, setCopiedResponse] = useState(false);

  const endpoint = MOCK_API_ENDPOINTS.find((e) => e.id === selectedEndpointId) || MOCK_API_ENDPOINTS[0];
  const activeKey = keys.find((k) => k.id === currentKeyId) || null;

  const handleExecuteRequest = async () => {
    setIsLoading(true);

    const startTime = performance.now();
    // Simulate real network flight
    await new Promise((r) => setTimeout(r, 120 + Math.random() * 80));
    const duration = Math.round(performance.now() - startTime);

    let effectiveKey = activeKey;
    let sentKeyStr = activeKey ? activeKey.maskedKey : 'NONE';

    if (customKeyOverride.trim()) {
      sentKeyStr = customKeyOverride.trim();
      // Check if custom key matches any known key or is raw
      const matched = keys.find((k) => k.maskedKey === sentKeyStr || k.tail === sentKeyStr.slice(-4));
      effectiveKey = matched || null;
    }

    // Check expiration or revocation
    let responseResult;
    if (effectiveKey && effectiveKey.status === 'revoked') {
      responseResult = {
        status: 401,
        data: {
          error: {
            code: 'key_revoked',
            message: 'This API key has been revoked and cannot authenticate requests.',
            key_id: effectiveKey.id,
          },
        },
        headers: {
          'Content-Type': 'application/json',
          'WWW-Authenticate': 'Bearer error="invalid_token", error_description="The token was revoked"',
        },
      };
    } else if (effectiveKey && effectiveKey.expiresAt && new Date(effectiveKey.expiresAt).getTime() < Date.now()) {
      responseResult = {
        status: 401,
        data: {
          error: {
            code: 'key_expired',
            message: 'This API key has expired.',
            expired_at: effectiveKey.expiresAt,
          },
        },
        headers: {
          'Content-Type': 'application/json',
          'WWW-Authenticate': 'Bearer error="invalid_token", error_description="The token has expired"',
        },
      };
    } else {
      let parsedBody = undefined;
      if (endpoint.method === 'POST') {
        try {
          parsedBody = JSON.parse(requestBodyText);
        } catch {
          parsedBody = { raw: requestBodyText };
        }
      }
      responseResult = endpoint.mockResponse(effectiveKey, parsedBody);
      if (effectiveKey && responseResult.status < 400) {
        onRecordRequest(effectiveKey.id);
      }
    }

    const statusTexts: Record<number, string> = {
      200: 'OK',
      201: 'Created',
      401: 'Unauthorized',
      403: 'Forbidden',
      429: 'Too Many Requests',
    };

    const result: TestExecutionResult = {
      endpoint: endpoint.path,
      method: endpoint.method,
      status: responseResult.status,
      statusText: statusTexts[responseResult.status] || 'Response',
      durationMs: duration,
      responseHeaders: {
        'Content-Type': 'application/json; charset=utf-8',
        'Date': new Date().toUTCString(),
        'Server': 'API-Gateway/2.4',
        ...responseResult.headers,
      },
      responseBody: responseResult.data,
      timestamp: new Date().toLocaleTimeString(),
      sentKey: sentKeyStr,
    };

    setLastResult(result);
    setIsLoading(false);
  };

  const handleCopyResponseBody = () => {
    if (!lastResult) return;
    navigator.clipboard.writeText(JSON.stringify(lastResult.responseBody, null, 2));
    setCopiedResponse(true);
    onToast('Response JSON Copied!');
    setTimeout(() => setCopiedResponse(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-amber-400" />
            Interactive API Sandbox
          </h2>
          <p className="text-xs text-zinc-400">
            Test authorization, scope validation, rate-limiting, and error simulation against real mock endpoints
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Request Configuration */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-xl">
            {/* Select API Key */}
            <div>
              <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                Authentication Key
              </label>
              <select
                value={currentKeyId}
                onChange={(e) => {
                  setCurrentKeyId(e.target.value);
                  setCustomKeyOverride('');
                }}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                {keys.map((k) => (
                  <option key={k.id} value={k.id}>
                    {k.name} ({k.maskedKey}) - [{k.environment}]
                  </option>
                ))}
              </select>

              {activeKey && (
                <div className="mt-2 text-[11px] text-zinc-400 flex flex-wrap items-center gap-1.5 bg-zinc-950/60 p-2 rounded-lg border border-zinc-800/60">
                  <span className="text-zinc-500">Active Scopes:</span>
                  {activeKey.scopes.map((s) => (
                    <span key={s} className="font-mono text-zinc-300">
                      {s}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Select Endpoint */}
            <div>
              <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                API Endpoint
              </label>
              <div className="space-y-1.5">
                {MOCK_API_ENDPOINTS.map((ep) => {
                  const isSelected = ep.id === selectedEndpointId;
                  const methodColor =
                    ep.method === 'GET'
                      ? 'text-sky-400 bg-sky-400/10'
                      : ep.method === 'POST'
                      ? 'text-emerald-400 bg-emerald-400/10'
                      : 'text-rose-400 bg-rose-400/10';

                  return (
                    <div
                      key={ep.id}
                      onClick={() => setSelectedEndpointId(ep.id)}
                      className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                        isSelected
                          ? 'border-amber-400/50 bg-amber-400/5'
                          : 'border-zinc-800/80 hover:bg-zinc-800/30'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${methodColor}`}>
                          {ep.method}
                        </span>
                        <span className="text-xs font-mono text-zinc-200">{ep.path}</span>
                      </div>
                      <div className="text-[11px] text-zinc-400 mt-1">{ep.description}</div>
                      {ep.requiredScopes.length > 0 && (
                        <div className="text-[10px] text-amber-400/80 mt-0.5 font-mono">
                          Requires: {ep.requiredScopes.join(', ')}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Request Body (for POST) */}
            {endpoint.method === 'POST' && (
              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
                  Request Payload (JSON)
                </label>
                <textarea
                  value={requestBodyText}
                  onChange={(e) => setRequestBodyText(e.target.value)}
                  rows={4}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs font-mono text-zinc-200 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}

            {/* Execute Button */}
            <button
              onClick={handleExecuteRequest}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-zinc-950 font-semibold text-xs rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Transmitting Request...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Send API Request</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Live HTTP Response Console */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-full min-h-[460px]">
            {/* Console Header */}
            <div className="px-4 py-3 border-b border-zinc-800 bg-zinc-900/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
                  <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
                  <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
                </div>
                <span className="text-xs font-mono text-zinc-400">Response Console</span>
              </div>

              {lastResult && (
                <div className="flex items-center gap-3 text-xs">
                  {/* Status */}
                  <span
                    className={`font-mono font-bold px-2 py-0.5 rounded text-[11px] ${
                      lastResult.status < 300
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : lastResult.status === 401
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}
                  >
                    {lastResult.status} {lastResult.statusText}
                  </span>

                  {/* Latency */}
                  <span className="font-mono text-zinc-500 text-[11px]">{lastResult.durationMs}ms</span>

                  {/* Copy Button */}
                  <button
                    onClick={handleCopyResponseBody}
                    className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 transition-colors"
                    title="Copy response body"
                  >
                    {copiedResponse ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )}
            </div>

            {/* Response Sub-tabs */}
            {lastResult && (
              <div className="px-4 py-1.5 border-b border-zinc-800 bg-zinc-900/20 flex items-center gap-3 text-xs">
                <button
                  onClick={() => setActiveResponseTab('body')}
                  className={`pb-0.5 border-b-2 font-medium transition-colors ${
                    activeResponseTab === 'body'
                      ? 'border-amber-400 text-amber-300'
                      : 'border-transparent text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Body
                </button>
                <button
                  onClick={() => setActiveResponseTab('headers')}
                  className={`pb-0.5 border-b-2 font-medium transition-colors ${
                    activeResponseTab === 'headers'
                      ? 'border-amber-400 text-amber-300'
                      : 'border-transparent text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Headers ({Object.keys(lastResult.responseHeaders).length})
                </button>
              </div>
            )}

            {/* Output Display */}
            <div className="p-4 flex-1 overflow-auto font-mono text-xs">
              {!lastResult ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-zinc-500 py-16">
                  <Terminal className="w-8 h-8 text-zinc-700 mb-2" />
                  <p className="text-zinc-400 text-xs">Awaiting API request</p>
                  <p className="text-zinc-600 text-[11px] max-w-xs mt-1">
                    Select an endpoint, click "Send API Request" to test bearer authentication and inspect headers.
                  </p>
                </div>
              ) : activeResponseTab === 'body' ? (
                <pre className="text-zinc-200 leading-relaxed overflow-x-auto whitespace-pre-wrap select-all">
                  {JSON.stringify(lastResult.responseBody, null, 2)}
                </pre>
              ) : (
                <div className="space-y-1.5">
                  {Object.entries(lastResult.responseHeaders).map(([key, val]) => (
                    <div key={key} className="flex items-start gap-2 text-xs">
                      <span className="text-zinc-400 font-medium shrink-0">{key}:</span>
                      <span className="text-amber-300 break-all">{val}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* cURL Equivalent Footer */}
            <div className="px-4 py-2.5 border-t border-zinc-800 bg-zinc-900/40 text-[11px] font-mono text-zinc-400 flex items-center justify-between gap-2 overflow-x-auto">
              <span className="truncate text-zinc-400">
                curl -X {endpoint.method} "https://api.example.com{endpoint.path}" -H "Authorization: Bearer {activeKey ? activeKey.maskedKey : 'YOUR_KEY'}"
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
