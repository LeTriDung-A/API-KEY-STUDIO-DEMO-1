import React, { useState } from 'react';
import {
  BookOpen,
  X,
  Shield,
  Lock,
  Bot,
  KeyRound,
  ExternalLink,
  Terminal,
  GitBranch,
  Cpu,
  CheckCircle2,
  FolderTree,
  Send,
  Zap,
  Sparkles,
} from 'lucide-react';

interface SecurityGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SecurityGuideModal: React.FC<SecurityGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'compare' | 'download' | 'config' | 'usecases'>('compare');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-5 max-h-[88vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-zinc-100">
                Cẩm Nang Toàn Diện: Mã Nguồn Mở & OpenClaw
              </h3>
              <p className="text-xs text-zinc-400">
                Phổ cập kiến thức từ cơ bản đến thực tế cho người mới bắt đầu
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200 p-1 rounded-lg hover:bg-zinc-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 p-1 bg-zinc-950 border border-zinc-800 rounded-xl text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('compare')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeTab === 'compare'
                ? 'bg-zinc-800 text-amber-300 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            1. Bản demo này có giống thật không?
          </button>
          <button
            onClick={() => setActiveTab('download')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeTab === 'download'
                ? 'bg-zinc-800 text-amber-300 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            2. Cách tải mã nguồn mở về máy
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeTab === 'config'
                ? 'bg-zinc-800 text-amber-300 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            3. Cách cài đặt & sử dụng
          </button>
          <button
            onClick={() => setActiveTab('usecases')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeTab === 'usecases'
                ? 'bg-zinc-800 text-amber-300 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            4. Ứng dụng thực tế làm được gì?
          </button>
        </div>

        {/* Tab 1: So sánh bản Demo vs Bản chạy thật */}
        {activeTab === 'compare' && (
          <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
            <div className="p-4 bg-amber-400/10 border border-amber-400/20 rounded-xl">
              <h4 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Câu trả lời: RẤT GIỐNG VỀ MẶT KIẾN TRÚC & NGUYÊN LÝ HOẠT ĐỘNG!
              </h4>
              <p className="text-zinc-300 text-xs mt-1.5">
                Bản demo trên web bạn vừa chạy mô phỏng chính xác 100% cách mà dự án mã nguồn mở OpenClaw (trước đây là ClawdBot/MoltBot) được xây dựng và vận hành.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Điểm giống nhau 100%:</span>
                </div>
                <ul className="space-y-1.5 text-zinc-400 text-[11px] list-disc list-inside">
                  <li><strong className="text-zinc-200">Markdown-as-Config:</strong> Nhân cách (<code className="text-amber-300">SOUL.md</code>), ký ức dài hạn (<code className="text-amber-300">MEMORY.md</code>), và công cụ (<code className="text-amber-300">TOOLS.md</code>) đều lưu bằng file văn bản Markdown y hệt mã nguồn gốc.</li>
                  <li><strong className="text-zinc-200">Bộ não AI thực tế:</strong> Trực tiếp gọi Google Gemini AI để tư duy, lập luận và quyết định công cụ.</li>
                  <li><strong className="text-zinc-200">Mô hình Gateway:</strong> Dùng daemon trung gian (port 18789) để tiếp nhận lệnh từ nhiều kênh (Telegram, Web, Discord).</li>
                  <li><strong className="text-zinc-200">Vòng lặp tự trị (Agentic Loop):</strong> Nhận tin $\rightarrow$ Đọc ngữ cảnh $\rightarrow$ Suy luận $\rightarrow$ Gọi tool $\rightarrow$ Phản hồi.</li>
                </ul>
              </div>

              <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                <div className="font-semibold text-amber-400 flex items-center gap-1.5">
                  <Zap className="w-4 h-4" />
                  <span>Điểm khác biệt duy nhất:</span>
                </div>
                <ul className="space-y-1.5 text-zinc-400 text-[11px] list-disc list-inside">
                  <li><strong className="text-zinc-200">Môi trường chạy lệnh:</strong> Bản Web demo chạy lệnh trong một môi trường sandbox an toàn trên trình duyệt để không làm ảnh hưởng máy tính của bạn.</li>
                  <li><strong className="text-zinc-200">Khi cài thật trên máy tính:</strong> Lệnh <code className="text-amber-300">bash</code> sẽ thao tác trực tiếp với ổ cứng, mở trình duyệt thật (Chrome), tự tạo repo Git thật và tự gửi tin nhắn Telegram thực tế đến điện thoại của bạn!</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Cách tải mã nguồn mở */}
        {activeTab === 'download' && (
          <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
              <h4 className="font-bold text-zinc-100 flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-amber-400" />
                <span>Mã nguồn mở (Open Source) là gì?</span>
              </h4>
              <p className="text-zinc-400 text-[11px]">
                Là phần mềm mà toàn bộ mã nguồn lập trình được tác giả công khai trên Internet (thường là trên GitHub). Bất kỳ ai cũng có quyền xem, tải về máy tính của mình, chỉnh sửa và tự chạy (Self-hosted) mà không bị phụ thuộc vào máy chủ của công ty nào.
              </p>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-amber-300">Cách 1: Tải qua Git (Chuẩn nhất dành cho lập trình viên)</div>
                <p className="text-[11px] text-zinc-400">Cài đặt công cụ Git từ <code className="text-zinc-300">git-scm.com</code>, sau đó mở Terminal gõ lệnh:</p>
                <pre className="p-2 bg-zinc-900 border border-zinc-800 rounded text-amber-300 font-mono text-[11px] select-all">git clone https://github.com/openclaw/openclaw.git</pre>
              </div>

              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-amber-300">Cách 2: Cài đặt gói qua NPM / NPX (Nhanh nhất cho người mới)</div>
                <p className="text-[11px] text-zinc-400">Không cần tải code thủ công, Node.js sẽ tự động tải phiên bản mới nhất:</p>
                <pre className="p-2 bg-zinc-900 border border-zinc-800 rounded text-amber-300 font-mono text-[11px] select-all">npx openclaw onboard</pre>
              </div>

              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
                <div className="font-semibold text-amber-300">Cách 3: Tải trực tiếp file ZIP</div>
                <p className="text-[11px] text-zinc-400">Trên trang GitHub của dự án, bấm nút xanh <strong className="text-zinc-200">"Code"</strong> $\rightarrow$ chọn <strong className="text-zinc-200">"Download ZIP"</strong>, sau đó giải nén ra thư mục máy tính.</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Cài đặt & Sử dụng */}
        {activeTab === 'config' && (
          <div className="space-y-4 text-xs text-zinc-300 leading-relaxed">
            <div className="space-y-3">
              <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                <div className="font-semibold text-zinc-200 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-amber-400 text-zinc-950 font-bold flex items-center justify-center text-[11px]">1</span>
                  <span>Cài đặt môi trường runtime (Node.js)</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Hầu hết các dự án AI Agent hiện đại như OpenClaw viết bằng TypeScript/JavaScript. Bạn vào trang <strong>nodejs.org</strong> tải bản LTS và cài đặt như phần mềm bình thường.
                </p>
              </div>

              <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                <div className="font-semibold text-zinc-200 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-amber-400 text-zinc-950 font-bold flex items-center justify-center text-[11px]">2</span>
                  <span>Chuẩn bị API Key cho mô hình AI</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Agent cần một "bộ não" để suy nghĩ. Bạn lấy API Key từ Google AI Studio (<code className="text-amber-400">GEMINI_API_KEY</code>) hoặc OpenAI/Anthropic, sau đó tạo file <code className="text-amber-300">.env</code> trong thư mục dự án:
                </p>
                <pre className="p-2 bg-zinc-900 border border-zinc-800 rounded text-amber-300 font-mono text-[11px]">GEMINI_API_KEY=AIzaSy...&#10;OPENCLAW_GATEWAY_PORT=18789</pre>
              </div>

              <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                <div className="font-semibold text-zinc-200 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-amber-400 text-zinc-950 font-bold flex items-center justify-center text-[11px]">3</span>
                  <span>Khởi động Gateway Daemon</span>
                </div>
                <pre className="p-2 bg-zinc-900 border border-zinc-800 rounded text-amber-300 font-mono text-[11px]">openclaw start</pre>
                <p className="text-[11px] text-zinc-400">Mở trình duyệt vào <code className="text-amber-400">http://localhost:18789</code> là có thể bắt đầu ra lệnh.</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Ứng dụng thực tế */}
        {activeTab === 'usecases' && (
          <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-amber-400" />
                <span>1. Lập trình viên tự động hóa (Autonomous Coding Agent)</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Bạn nhắn trên Telegram: <em>"Hãy đọc repo github này, tìm lỗi logic trong file auth.ts và viết test case bằng vitest"</em>. OpenClaw sẽ tự chạy lệnh `git checkout`, sửa code, chạy lệnh `npm test` và thông báo kết quả cho bạn.
              </p>
            </div>

            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-2">
                <Send className="w-4 h-4 text-sky-400" />
                <span>2. Trợ lý cá nhân điều khiển qua Telegram/WhatsApp</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Agent chạy 24/7 trên một chiếc máy tính cá nhân hoặc máy chủ VPS giá rẻ ($5/tháng). Bạn chỉ cần nhắn tin Telegram là nó có thể tóm tắt tài liệu, tải video, theo dõi giá thị trường hoặc gửi báo cáo hàng ngày.
              </p>
            </div>

            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>3. Quản trị hệ thống & Giám sát Server (DevOps)</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Agent tự động kiểm tra dung lượng ổ đĩa, kiểm tra tình trạng kết nối mạng, khởi động lại các container Docker bị crash và cảnh báo bảo mật khi phát hiện IP lạ.
              </p>
            </div>

            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
              <div className="font-bold text-amber-300 flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-purple-400" />
                <span>4. Bảo mật tuyệt đối vì dữ liệu ở trên máy bạn</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Khác với các dịch vụ chat đám mây đóng gói sẵn, toàn bộ file của bạn lưu trong thư mục cục bộ, lịch sử chat nằm ở máy bạn, bạn hoàn toàn làm chủ hệ thống.
              </p>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
          <span className="text-[11px] text-zinc-500">Mã nguồn mở · Local-first Architecture</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-100 hover:bg-white text-zinc-950 text-xs font-semibold rounded-lg transition-colors"
          >
            Đóng Hướng Dẫn
          </button>
        </div>
      </div>
    </div>
  );
};
