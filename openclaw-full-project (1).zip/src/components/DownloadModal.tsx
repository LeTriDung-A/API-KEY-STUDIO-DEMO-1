import React, { useState } from 'react';
import JSZip from 'jszip';
import { WorkspaceFiles } from '../types/openclaw';
import {
  Download,
  X,
  Terminal,
  Check,
  Copy,
  FolderArchive,
  Laptop,
  CheckCircle2,
  Layers,
  ArrowDownToLine,
  GitBranch,
  ExternalLink,
  Globe,
  UploadCloud,
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  workspaceFiles: WorkspaceFiles;
  activeKeyToken?: string;
  onToast: (title: string, message?: string) => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  workspaceFiles,
  activeKeyToken,
  onToast,
}) => {
  const [modalTab, setModalTab] = useState<'download' | 'github'>('download');
  const [selectedOs, setSelectedOs] = useState<'windows' | 'mac' | 'linux'>('windows');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [isZippingWorkspace, setIsZippingWorkspace] = useState(false);
  const [isDownloadingFullProject, setIsDownloadingFullProject] = useState(false);

  // GitHub customizer
  const [githubUser, setGithubUser] = useState('your-github-username');
  const [githubRepo, setGithubRepo] = useState('openclaw-agent-studio');

  if (!isOpen) return null;

  // Option 1: Download Complete Source Code (.ZIP)
  const handleDownloadFullProject = async () => {
    setIsDownloadingFullProject(true);
    onToast('Đang tạo và tải mã nguồn...', 'Đang nén file openclaw-full-project.zip...');

    try {
      const res = await fetch('/api/download/project-zip');
      if (!res.ok) {
        throw new Error(`Server returned HTTP ${res.status}`);
      }
      const blob = await res.blob();
      if (!blob || blob.size === 0) {
        throw new Error('File tải về bị rỗng (0 bytes)');
      }

      // Trigger reliable browser save via Blob URL
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = 'openclaw-full-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);

      onToast(
        'Đã tải file ZIP thành công!',
        `Kích thước: ${Math.round(blob.size / 1024)} KB. Đã lưu vào Downloads của máy tính bạn.`
      );
    } catch (err: any) {
      console.warn('Backend ZIP fetch failed, using client generation fallback:', err);
      try {
        const zip = new JSZip();
        Object.entries(workspaceFiles).forEach(([name, content]) => {
          zip.file(name, content);
        });
        zip.file(
          'HUONG_DAN_CHAY.md',
          '# HƯỚNG DẪN CHẠY\n\n1. Giải nén thư mục\n2. Mở terminal gõ: npm install && npm run dev\n'
        );
        const fallbackBlob = await zip.generateAsync({ type: 'blob' });
        const blobUrl = URL.createObjectURL(fallbackBlob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = 'openclaw-full-project.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
        onToast('Đã tải file ZIP dự phòng!', 'Đã tạo và tải file zip thành công.');
      } catch (fallbackErr: any) {
        onToast('Lỗi tải file', err?.message || 'Không thể tạo file zip');
      }
    } finally {
      setIsDownloadingFullProject(false);
    }
  };

  // Option 2: Download Workspace Files only
  const handleDownloadWorkspaceZip = async () => {
    setIsZippingWorkspace(true);
    try {
      const zip = new JSZip();

      // Add all markdown and config files
      Object.entries(workspaceFiles).forEach(([filename, content]) => {
        zip.file(filename, content);
      });

      // Add a ready-to-run package.json and start script
      const packageJson = {
        name: 'openclaw-local-workspace',
        version: '1.0.0',
        description: 'OpenClaw Autonomous Agent local workspace',
        main: 'src/index.js',
        scripts: {
          start: 'openclaw start',
          onboard: 'openclaw onboard',
          test: 'node src/index.js',
        },
        dependencies: {
          openclaw: '^1.0.0',
        },
      };
      zip.file('package.json', JSON.stringify(packageJson, null, 2));

      // Add .env file with generated API Key
      const envContent = `# OpenClaw Local Environment Configuration\n# Generated at: ${new Date().toISOString()}\nOPENCLAW_GATEWAY_PORT=18789\nOPENCLAW_GATEWAY_HOST=127.0.0.1\nGEMINI_API_KEY="${activeKeyToken || 'sk_live_claw_demo_98f1a23e98124b'}"\nOPENCLAW_WORKSPACE_DIR=.\n`;
      zip.file('.env', envContent);

      const readmeContent = `# OpenClaw Local Workspace\n\n1. Cài đặt OpenClaw CLI:\n\`\`\`bash\nnpm install -g openclaw@latest\n\`\`\`\n\n2. Khởi động Agent Gateway:\n\`\`\`bash\nopenclaw start\n\`\`\`\nTruy cập Web: http://localhost:18789\n`;
      zip.file('README.md', readmeContent);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'openclaw-workspace.zip';
      a.click();
      URL.revokeObjectURL(url);

      onToast('Đã tải openclaw-workspace.zip!', 'Giải nén và mở bằng VS Code hoặc Terminal.');
    } catch (err: any) {
      onToast('Lỗi tải file ZIP', err?.message || 'Không thể tạo file ZIP');
    } finally {
      setIsZippingWorkspace(false);
    }
  };

  const handleCopyCommand = async (cmd: string, id: string) => {
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedCmd(id);
      onToast('Đã sao chép lệnh vào Clipboard!');
      setTimeout(() => setCopiedCmd(null), 2500);
    } catch {
      // fallback
    }
  };

  const cleanUser = githubUser.trim() || 'your-username';
  const cleanRepo = githubRepo.trim() || 'openclaw-agent-studio';

  const gitSteps = [
    {
      id: 'git-step-1',
      title: 'Bước 1: Khởi tạo Git trong thư mục dự án vừa giải nén',
      desc: 'Mở Terminal (hoặc PowerShell) tại thư mục chứa code và chạy:',
      command: `git init\ngit add .\ngit commit -m "feat: initial commit OpenClaw Agent Studio"`,
    },
    {
      id: 'git-step-2',
      title: 'Bước 2: Tạo Repository mới trên GitHub & liên kết',
      desc: `Vào github.com/new tạo repo tên "${cleanRepo}", sau đó liên kết bằng lệnh:`,
      command: `git branch -M main\ngit remote add origin https://github.com/${cleanUser}/${cleanRepo}.git`,
    },
    {
      id: 'git-step-3',
      title: 'Bước 3: Đẩy toàn bộ mã nguồn lên trang GitHub cá nhân',
      desc: 'Chạy lệnh push cuối cùng để code xuất hiện trên profile GitHub:',
      command: `git push -u origin main`,
    },
  ];

  const osCommands = {
    windows: [
      {
        id: 'cmd-win-install',
        label: '1. Cài đặt OpenClaw CLI qua npm (Mở PowerShell hoặc CMD):',
        code: 'npm install -g openclaw@latest',
      },
      {
        id: 'cmd-win-onboard',
        label: '2. Khởi tạo và thiết lập nhanh (Onboarding Wizard):',
        code: 'npx openclaw onboard',
      },
      {
        id: 'cmd-win-start',
        label: '3. Khởi chạy Gateway và Agent trên máy tính:',
        code: 'openclaw start',
      },
    ],
    mac: [
      {
        id: 'cmd-mac-install',
        label: '1. Cài đặt OpenClaw CLI (Mở Terminal macOS):',
        code: 'npm install -g openclaw@latest',
      },
      {
        id: 'cmd-mac-onboard',
        label: '2. Cấu hình tự động kết nối mô hình và kênh chat:',
        code: 'npx openclaw onboard',
      },
      {
        id: 'cmd-mac-start',
        label: '3. Khởi động daemon cục bộ:',
        code: 'openclaw start',
      },
    ],
    linux: [
      {
        id: 'cmd-linux-install',
        label: '1. Cài đặt trên Ubuntu/Debian/Arch Linux:',
        code: 'sudo npm install -g openclaw@latest',
      },
      {
        id: 'cmd-linux-onboard',
        label: '2. Chạy wizard thiết lập thư mục và quyền thực thi:',
        code: 'npx openclaw onboard',
      },
      {
        id: 'cmd-linux-start',
        label: '3. Chạy Gateway daemon nền:',
        code: 'openclaw start --daemon',
      },
    ],
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-center text-amber-400">
              {modalTab === 'download' ? <Download className="w-5 h-5" /> : <GitBranch className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-semibold text-zinc-100">
                {modalTab === 'download' ? 'Tải Mã Nguồn Về Máy' : 'Hướng Dẫn Lưu Lên GitHub Profile'}
              </h3>
              <p className="text-xs text-zinc-400">
                {modalTab === 'download'
                  ? 'Tải file zip về máy tính cá nhân hoặc chạy bằng CLI'
                  : 'Đẩy toàn bộ dự án lên kho lưu trữ GitHub của bạn trong 3 bước'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-200 p-1.5 rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-3 pb-0 bg-zinc-950/40 border-b border-zinc-800 flex items-center gap-2">
          <button
            onClick={() => setModalTab('download')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              modalTab === 'download'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>1. Tải về máy (.ZIP)</span>
          </button>
          <button
            onClick={() => setModalTab('github')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
              modalTab === 'github'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>2. Lưu lên GitHub Profile (Đẩy code)</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[72vh] overflow-y-auto">
          {modalTab === 'download' ? (
            <>
              {/* Card 1: TẢI TOÀN BỘ SOURCE CODE DỰ ÁN (Khuyến nghị) */}
              <div className="bg-gradient-to-br from-amber-400/15 via-zinc-950 to-zinc-950 border-2 border-amber-400/40 rounded-2xl p-5 shadow-xl space-y-3.5">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-400 text-zinc-950 flex items-center justify-center shrink-0 font-bold shadow-md">
                      <Layers className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-zinc-100">
                          Tải Toàn Bộ Mã Nguồn Dự Án (Full Project .ZIP)
                        </h4>
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-400 text-zinc-950">
                          Khuyên Dùng
                        </span>
                      </div>
                      <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
                        Tải về 100% tất cả các file mã nguồn của ứng dụng này (React 19, TypeScript, Express backend, giao diện OpenClaw, bộ tạo API Key và sandbox).
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-zinc-900/80 border border-zinc-800 rounded-xl text-xs space-y-1.5 text-zinc-400">
                  <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Gói bao gồm:</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[11px] font-mono text-zinc-300 pl-5">
                    <span>• package.json & tsconfig.json</span>
                    <span>• server.ts (Express backend)</span>
                    <span>• src/ (Toàn bộ React components)</span>
                    <span>• vite.config.ts & index.html</span>
                    <span>• HUONG_DAN_CHAY.md</span>
                    <span>• .env.example cấu hình</span>
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-end">
                  <button
                    onClick={handleDownloadFullProject}
                    disabled={isDownloadingFullProject}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-zinc-950 shadow-lg shadow-amber-400/20 transition-all cursor-pointer"
                  >
                    <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
                    <span>{isDownloadingFullProject ? 'Đang chuẩn bị file...' : 'Tải Toàn Bộ Mã Nguồn (.ZIP)'}</span>
                  </button>
                </div>
              </div>

              {/* Card 2: TẢI CHỈ GÓI CẤU HÌNH WORKSPACE OPENCLAW */}
              <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <FolderArchive className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-zinc-200">
                        Chỉ Tải File Cấu Hình Workspace OpenClaw (.ZIP)
                      </h4>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        Chỉ chứa các file Markdown-as-Config: <code className="text-amber-300">SOUL.md</code>, <code className="text-amber-300">MEMORY.md</code>, <code className="text-amber-300">TOOLS.md</code>, <code className="text-amber-300">openclaw.json</code>, và <code className="text-amber-300">.env</code>.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleDownloadWorkspaceZip}
                    disabled={isZippingWorkspace}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-colors shrink-0 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isZippingWorkspace ? 'Đang nén...' : 'Tải Workspace (.ZIP)'}</span>
                  </button>
                </div>
              </div>

              {/* Card 3: Cài đặt OpenClaw CLI */}
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-semibold text-zinc-200 flex items-center gap-2">
                      <Terminal className="w-4 h-4 text-emerald-400" />
                      <span>Cách Cài Đặt OpenClaw CLI Trực Tiếp Lên Máy</span>
                    </h4>
                    <p className="text-[11px] text-zinc-400 mt-0.5">
                      Yêu cầu máy tính đã cài đặt <a href="https://nodejs.org" target="_blank" rel="noreferrer" className="text-amber-400 underline">Node.js</a>
                    </p>
                  </div>

                  <div className="flex items-center p-1 bg-zinc-950 border border-zinc-800 rounded-lg text-xs">
                    {(['windows', 'mac', 'linux'] as const).map((os) => (
                      <button
                        key={os}
                        onClick={() => setSelectedOs(os)}
                        className={`px-2.5 py-1 font-medium capitalize rounded-md transition-colors text-[11px] cursor-pointer ${
                          selectedOs === os
                            ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {os === 'windows' ? 'Windows' : os === 'mac' ? 'macOS' : 'Linux'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  {osCommands[selectedOs].map((step) => {
                    const isCopied = copiedCmd === step.id;
                    return (
                      <div key={step.id} className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
                        <div className="text-[11px] text-zinc-400 font-medium">{step.label}</div>
                        <div className="flex items-center justify-between gap-2 p-2 bg-zinc-900 border border-zinc-800/80 rounded-lg font-mono text-xs text-amber-300">
                          <span className="truncate select-all">{step.code}</span>
                          <button
                            onClick={() => handleCopyCommand(step.code, step.id)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs font-sans font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-800 hover:bg-zinc-700 rounded transition-colors shrink-0 cursor-pointer"
                          >
                            {isCopied ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Đã copy</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            /* TAB 2: HƯỚNG DẪN LƯU LÊN GITHUB PROFILE */
            <div className="space-y-5">
              {/* Giới thiệu */}
              <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-bold text-zinc-100 text-xs flex items-center gap-2">
                    <Globe className="w-4 h-4 text-sky-400" />
                    <span>Tùy Chỉnh Thông Tin GitHub Của Bạn (Để Tự Động Sinh Lệnh):</span>
                  </div>
                  <a
                    href="https://github.com/new"
                    target="_blank"
                    rel="noreferrer"
                    className="text-amber-400 hover:text-amber-300 text-xs flex items-center gap-1 underline"
                  >
                    <span>Mở github.com/new</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] text-zinc-400 uppercase tracking-wider mb-1">
                      Tên tài khoản GitHub của bạn:
                    </label>
                    <input
                      type="text"
                      value={githubUser}
                      onChange={(e) => setGithubUser(e.target.value)}
                      placeholder="ví dụ: clan41857"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-zinc-400 uppercase tracking-wider mb-1">
                      Tên Repository muốn tạo:
                    </label>
                    <input
                      type="text"
                      value={githubRepo}
                      onChange={(e) => setGithubRepo(e.target.value)}
                      placeholder="ví dụ: openclaw-agent-studio"
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>

              {/* Các bước thực hiện bằng lệnh Git */}
              <div className="space-y-3">
                <div className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-amber-400" />
                  <span>Cách 1: Đẩy lên bằng 3 lệnh Git (Khuyên dùng):</span>
                </div>

                {gitSteps.map((step) => {
                  const isCopied = copiedCmd === step.id;
                  return (
                    <div key={step.id} className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2">
                      <div className="text-xs font-semibold text-zinc-200">{step.title}</div>
                      <div className="text-[11px] text-zinc-400">{step.desc}</div>
                      <div className="relative group">
                        <pre className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-lg font-mono text-[11px] text-amber-300 overflow-x-auto whitespace-pre-wrap select-all">
                          {step.command}
                        </pre>
                        <button
                          onClick={() => handleCopyCommand(step.command, step.id)}
                          className="absolute right-2 top-2 flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-800 hover:bg-zinc-700 rounded transition-colors cursor-pointer"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Đã copy</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy lệnh</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Cách kéo thả trực tiếp trên Web */}
              <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-2 text-xs text-zinc-400">
                <div className="font-semibold text-zinc-200 flex items-center gap-1.5">
                  <UploadCloud className="w-4 h-4 text-emerald-400" />
                  <span>Cách 2: Không cần gõ lệnh (Kéo thả trực tiếp trên web GitHub)</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-zinc-400 text-[11px] pl-1 leading-relaxed">
                  <li>Tải file <strong className="text-zinc-200">openclaw-full-project.zip</strong> ở tab bên cạnh và giải nén ra thư mục.</li>
                  <li>Truy cập <a href="https://github.com/new" target="_blank" rel="noreferrer" className="text-amber-400 underline">github.com/new</a> để tạo một Repository mới (đặt tên bất kỳ, để Public).</li>
                  <li>Tại trang repo vừa tạo, bấm vào dòng chữ nhỏ: <strong className="text-zinc-200">"uploading an existing file"</strong>.</li>
                  <li>Kéo toàn bộ các file trong thư mục vừa giải nén thả vào trình duyệt và bấm nút xanh <strong className="text-zinc-200">"Commit changes"</strong>!</li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-zinc-800 bg-zinc-950/40">
          <span className="text-xs text-zinc-500">Mã nguồn mở · Sẵn sàng đưa lên GitHub</span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-zinc-950 bg-zinc-100 hover:bg-white rounded-lg transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
