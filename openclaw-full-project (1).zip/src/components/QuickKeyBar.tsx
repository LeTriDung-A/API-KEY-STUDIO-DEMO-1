import React, { useState } from 'react';
import { ApiKey, KeyEnvironment } from '../types/apiKey';
import { generateCryptographicKey } from '../utils/crypto';
import { Zap, Copy, Check, ShieldCheck, Sparkles } from 'lucide-react';

interface QuickKeyBarProps {
  onAddKey: (key: ApiKey, plaintext: string) => void;
  onToast: (title: string, message?: string) => void;
}

export const QuickKeyBar: React.FC<QuickKeyBarProps> = ({ onAddKey, onToast }) => {
  const [selectedEnv, setSelectedEnv] = useState<KeyEnvironment>('production');
  const [latestKey, setLatestKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleQuickGenerateAndCopy = async () => {
    setIsGenerating(true);
    try {
      const prefix = selectedEnv === 'production' ? 'sk_live_' : selectedEnv === 'staging' ? 'sk_stg_' : 'sk_test_';
      const result = await generateCryptographicKey({
        prefix,
        byteEntropy: 24,
        includeChecksum: true,
      });

      const newKey: ApiKey = {
        id: `key_${Math.random().toString(36).substring(2, 10)}`,
        name: `Quick ${selectedEnv.charAt(0).toUpperCase() + selectedEnv.slice(1)} Key`,
        keyPrefix: prefix,
        maskedKey: result.maskedKey,
        hash: result.hash,
        tail: result.tail,
        environment: selectedEnv,
        scopes: ['read:data', 'read:users', 'write:records'],
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 90 * 86400000).toISOString(),
        lastUsedAt: null,
        rateLimit: { requestsPerMinute: 120, requestsPerDay: 20000 },
        allowedIps: [],
        status: 'active',
        requestCount: 0,
      };

      // Add to store
      onAddKey(newKey, result.fullKey);
      setLatestKey(result.fullKey);

      // Perform 1-click copy directly to user's clipboard!
      try {
        await navigator.clipboard.writeText(result.fullKey);
      } catch {
        const input = document.createElement('textarea');
        input.value = result.fullKey;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }

      setCopied(true);
      onToast('Key Generated & Copied!', 'Copied directly to your clipboard with 1-click.');
      setTimeout(() => setCopied(false), 3000);
    } catch (err: any) {
      onToast('Failed to generate key', err?.message || 'Error occurred');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyExisting = async () => {
    if (!latestKey) return;
    try {
      await navigator.clipboard.writeText(latestKey);
      setCopied(true);
      onToast('Copied to Clipboard!', 'Secret API Key ready to paste.');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-5 mb-8 shadow-xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left descriptor */}
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400 shrink-0">
            <Zap className="w-5 h-5 fill-amber-400/20" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-zinc-100">1-Click Key Generator</h3>
              <span className="text-[10px] font-medium tracking-wide uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Instant Copy
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5">
              Generates a cryptographically strong 192-bit key and copies it straight to your clipboard in one tap.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Environment Selector */}
          <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-lg p-1 text-xs">
            {(['production', 'staging', 'development'] as KeyEnvironment[]).map((env) => (
              <button
                key={env}
                onClick={() => setSelectedEnv(env)}
                className={`px-2.5 py-1 rounded font-medium capitalize transition-colors ${
                  selectedEnv === env
                    ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {env === 'production' ? 'Live' : env === 'staging' ? 'Staging' : 'Test'}
              </button>
            ))}
          </div>

          {/* 1-Click Generate & Copy Button */}
          <button
            onClick={handleQuickGenerateAndCopy}
            disabled={isGenerating}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-md active:scale-95 ${
              copied
                ? 'bg-emerald-500 text-zinc-950 shadow-emerald-500/20'
                : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-amber-500/10'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 stroke-[2.5]" />
                <span>{isGenerating ? 'Generating...' : 'Generate & Copy (1-Click)'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* If a key was just generated, show the quick-bar snippet */}
      {latestKey && (
        <div className="mt-4 pt-3.5 border-t border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-zinc-300 min-w-0">
            <span className="text-zinc-500 shrink-0 font-medium">Just Generated:</span>
            <span className="font-mono text-amber-300 truncate select-all">{latestKey}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopyExisting}
              className="flex items-center gap-1.5 px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-md transition-colors font-medium text-xs"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Again</span>
            </button>
            <span className="text-[11px] text-zinc-500">CRC32 Checksum Verified</span>
          </div>
        </div>
      )}
    </div>
  );
};
