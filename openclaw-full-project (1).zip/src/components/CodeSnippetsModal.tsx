import React, { useState } from 'react';
import { ApiKey } from '../types/apiKey';
import { Code2, X, Copy, Check } from 'lucide-react';

interface CodeSnippetsModalProps {
  isOpen: boolean;
  apiKey: ApiKey | null;
  onClose: () => void;
  onToast: (title: string) => void;
}

export const CodeSnippetsModal: React.FC<CodeSnippetsModalProps> = ({
  isOpen,
  apiKey,
  onClose,
  onToast,
}) => {
  const [selectedLang, setSelectedLang] = useState<'curl' | 'node' | 'python' | 'go' | 'rust'>('curl');
  const [copied, setCopied] = useState(false);

  if (!isOpen || !apiKey) return null;

  const keyPlaceholder = apiKey.maskedKey;

  const snippets: Record<string, string> = {
    curl: `# cURL Request with Bearer Token Authorization
curl -X GET "https://api.example.com/v1/auth/verify" \\
  -H "Authorization: Bearer ${keyPlaceholder}" \\
  -H "Content-Type: application/json"
`,
    node: `// Node.js (Fetch API or Axios)
const response = await fetch("https://api.example.com/v1/auth/verify", {
  method: "GET",
  headers: {
    "Authorization": "Bearer ${keyPlaceholder}",
    "Content-Type": "application/json"
  }
});

const data = await response.json();
console.log("Authentication status:", data);
`,
    python: `# Python (Requests / HTTPX)
import requests

url = "https://api.example.com/v1/auth/verify"
headers = {
    "Authorization": "Bearer ${keyPlaceholder}",
    "Content-Type": "application/json"
}

response = requests.get(url, headers=headers)
print("Response:", response.status_code, response.json())
`,
    go: `// Go (net/http standard library)
package main

import (
	"fmt"
	"io"
	"net/http"
)

func main() {
	req, _ := http.NewRequest("GET", "https://api.example.com/v1/auth/verify", nil)
	req.Header.Set("Authorization", "Bearer ${keyPlaceholder}")
	req.Header.Set("Content-Type", "application/json")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)
	fmt.Println("Response:", string(body))
}
`,
    rust: `// Rust (Reqwest)
#[tokio::main]
async fn main() -> Result<(), Box<dyn std.error::Error>> {
    let client = reqwest::Client::new();
    let res = client
        .get("https://api.example.com/v1/auth/verify")
        .bearer_auth("${keyPlaceholder}")
        .header("Content-Type", "application/json")
        .send()
        .await?
        .text()
        .await?;

    println!("Response: {}", res);
    Ok(())
}
`,
  };

  const currentSnippet = snippets[selectedLang];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentSnippet);
    setCopied(true);
    onToast('Code Snippet Copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-semibold text-zinc-100">API Integration Code Snippets</h3>
              <p className="text-xs text-zinc-400">Pre-configured requests for {apiKey.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Language Tabs */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 bg-zinc-950 border border-zinc-800 rounded-lg text-xs">
            {[
              { id: 'curl', label: 'cURL' },
              { id: 'node', label: 'Node.js' },
              { id: 'python', label: 'Python' },
              { id: 'go', label: 'Go' },
              { id: 'rust', label: 'Rust' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedLang(tab.id as any)}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  selectedLang === tab.id
                    ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-medium transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Snippet'}</span>
          </button>
        </div>

        {/* Code display */}
        <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl font-mono text-xs text-zinc-200 overflow-x-auto max-h-72">
          <pre>{currentSnippet}</pre>
        </div>

        <div className="text-[11px] text-zinc-500">
          Note: Replace <code className="text-amber-400">{keyPlaceholder}</code> with your actual plaintext secret in your local <code className="text-zinc-300">.env</code> file.
        </div>
      </div>
    </div>
  );
};
