import React, { useState } from 'react';
import { ApiKey, KeyEnvironment } from '../types/apiKey';
import {
  Search,
  Copy,
  Check,
  RefreshCw,
  Ban,
  Trash2,
  Code2,
  Play,
  KeyRound,
  MoreVertical,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';

interface KeysTableProps {
  keys: ApiKey[];
  onCopyKey: (keyString: string) => void;
  onOpenRotateModal: (key: ApiKey) => void;
  onRevokeKey: (keyId: string) => void;
  onDeleteKey: (keyId: string) => void;
  onOpenDetails: (key: ApiKey) => void;
  onOpenCodeSnippets: (key: ApiKey) => void;
  onTestInSandbox: (key: ApiKey) => void;
  onOpenCreate: () => void;
}

export const KeysTable: React.FC<KeysTableProps> = ({
  keys,
  onCopyKey,
  onOpenRotateModal,
  onRevokeKey,
  onDeleteKey,
  onOpenDetails,
  onOpenCodeSnippets,
  onTestInSandbox,
  onOpenCreate,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'production' | 'test' | 'revoked'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const filteredKeys = keys.filter((key) => {
    const matchesSearch =
      key.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      key.maskedKey.toLowerCase().includes(searchTerm.toLowerCase()) ||
      key.tail.includes(searchTerm);

    if (!matchesSearch) return false;

    if (filterTab === 'production') return key.environment === 'production';
    if (filterTab === 'test') return key.environment === 'development' || key.environment === 'staging';
    if (filterTab === 'revoked') return key.status === 'revoked' || key.status === 'expired';

    return true;
  });

  const handleCopy = (id: string, textToCopy: string) => {
    onCopyKey(textToCopy);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
      {/* Controls Bar */}
      <div className="p-4 border-b border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by key name, prefix or tail..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg pl-9 pr-3.5 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-amber-400 transition-colors"
          />
        </div>

        {/* Filter Segmented Controls (interactive buttons) */}
        <div className="flex items-center gap-1 p-1 bg-zinc-950 border border-zinc-800 rounded-lg">
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filterTab === 'all' ? 'bg-zinc-800 text-zinc-100 shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Keys ({keys.length})
          </button>
          <button
            onClick={() => setFilterTab('production')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filterTab === 'production'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Live ({keys.filter((k) => k.environment === 'production').length})
          </button>
          <button
            onClick={() => setFilterTab('test')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filterTab === 'test' ? 'bg-zinc-800 text-zinc-100 shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Test / Sandbox
          </button>
          <button
            onClick={() => setFilterTab('revoked')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              filterTab === 'revoked' ? 'bg-zinc-800 text-zinc-100 shadow-sm' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Inactive
          </button>
        </div>
      </div>

      {/* Table Body */}
      {filteredKeys.length === 0 ? (
        <div className="p-12 text-center">
          <KeyRound className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
          <h4 className="text-sm font-medium text-zinc-300">No API keys found</h4>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1 mb-4">
            No keys match your current filter or search criteria.
          </p>
          <button
            onClick={onOpenCreate}
            className="px-3.5 py-1.5 text-xs font-medium text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors"
          >
            Create API Key
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-zinc-800/80 bg-zinc-950/40 text-zinc-400 font-medium uppercase tracking-wider">
                <th className="py-3 px-4">Key Name & Environment</th>
                <th className="py-3 px-4">Key Token</th>
                <th className="py-3 px-4">Scopes</th>
                <th className="py-3 px-4">Status & Expiration</th>
                <th className="py-3 px-4">Requests</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {filteredKeys.map((key) => {
                const isCopied = copiedId === key.id;
                const isMenuOpen = activeMenuId === key.id;

                let statusDot = 'bg-emerald-400';
                let statusText = 'Active';
                if (key.status === 'expiring_soon') {
                  statusDot = 'bg-amber-400';
                  statusText = 'Expiring soon';
                } else if (key.status === 'expired') {
                  statusDot = 'bg-zinc-500';
                  statusText = 'Expired';
                } else if (key.status === 'revoked') {
                  statusDot = 'bg-rose-400';
                  statusText = 'Revoked';
                }

                return (
                  <tr
                    key={key.id}
                    className="hover:bg-zinc-800/30 transition-colors group"
                  >
                    {/* Name & Env */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-zinc-200 flex items-center gap-1.5">
                        <button
                          onClick={() => onOpenDetails(key)}
                          className="hover:text-amber-300 text-left transition-colors"
                        >
                          {key.name}
                        </button>
                      </div>
                      <div className="text-[11px] text-zinc-500 flex items-center gap-1.5 mt-0.5">
                        <span className="capitalize">{key.environment}</span>
                        <span aria-hidden="true">·</span>
                        <span>Created {new Date(key.createdAt).toLocaleDateString()}</span>
                        {key.rotationGracePeriodUntil && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-400">Grace period active</span>
                          </>
                        )}
                      </div>
                    </td>

                    {/* Masked Key & 1-Click Copy */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-zinc-300 bg-zinc-950 px-2 py-1 rounded border border-zinc-800/80 select-all">
                          {key.maskedKey}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopy(key.id, key.maskedKey)}
                          title="Copy key identifier"
                          className="p-1 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded transition-colors"
                        >
                          {isCopied ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Scopes */}
                    <td className="py-3 px-4 max-w-xs">
                      <div className="text-zinc-400 text-[11px] flex flex-wrap items-center gap-1">
                        {key.scopes.slice(0, 2).map((s) => (
                          <span key={s} className="font-mono text-zinc-300">
                            {s}
                          </span>
                        ))}
                        {key.scopes.length > 2 && (
                          <span className="text-zinc-500">+{key.scopes.length - 2} more</span>
                        )}
                      </div>
                    </td>

                    {/* Status & Expiry */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <span className={`w-1.5 h-1.5 rounded-full ${statusDot}`} />
                        <span className="text-zinc-300">{statusText}</span>
                      </div>
                      <div className="text-[10px] text-zinc-500 mt-0.5">
                        {key.expiresAt
                          ? `Expires ${new Date(key.expiresAt).toLocaleDateString()}`
                          : 'Never expires'}
                      </div>
                    </td>

                    {/* Request stats */}
                    <td className="py-3 px-4">
                      <div className="font-mono text-zinc-200">
                        {key.requestCount.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        {key.lastUsedAt ? 'Active recently' : 'Never used'}
                      </div>
                    </td>

                    {/* Action buttons */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onTestInSandbox(key)}
                          className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded transition-colors"
                          title="Test key in API sandbox"
                        >
                          <Play className="w-3.5 h-3.5 text-sky-400" />
                        </button>

                        <button
                          onClick={() => onOpenCodeSnippets(key)}
                          className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded transition-colors"
                          title="View code integration snippets (curl, node, python)"
                        >
                          <Code2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onOpenRotateModal(key)}
                          className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 rounded transition-colors"
                          title="Rotate / Roll Key with zero downtime"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>

                        {key.status === 'active' && (
                          <button
                            onClick={() => onRevokeKey(key.id)}
                            className="p-1.5 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800 rounded transition-colors"
                            title="Revoke key immediately"
                          >
                            <Ban className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => onDeleteKey(key.id)}
                          className="p-1.5 text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 rounded transition-colors"
                          title="Delete key"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
