import React from 'react';
import { ApiKey } from '../types/apiKey';
import { Shield, CheckCircle2, Activity, Lock } from 'lucide-react';

interface KeyStatsProps {
  keys: ApiKey[];
  onOpenCreate: () => void;
}

export const KeyStats: React.FC<KeyStatsProps> = ({ keys }) => {
  const activeKeys = keys.filter(k => k.status === 'active');
  const expiringSoonKeys = keys.filter(k => k.status === 'expiring_soon');
  const productionKeys = keys.filter(k => k.environment === 'production' && k.status === 'active');
  const totalRequests = keys.reduce((sum, k) => sum + k.requestCount, 0);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {/* Metric 1 */}
      <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4">
        <div className="flex items-center justify-between text-zinc-400 mb-2">
          <span className="text-xs font-medium uppercase tracking-wider">Active Keys</span>
          <Shield className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="text-2xl font-bold text-zinc-100 font-mono tracking-tight">
          {activeKeys.length}
        </div>
        <div className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5">
          <span>{productionKeys.length} live production</span>
          <span aria-hidden="true">·</span>
          <span>{keys.length - productionKeys.length} sandbox/stg</span>
        </div>
      </div>

      {/* Metric 2 */}
      <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4">
        <div className="flex items-center justify-between text-zinc-400 mb-2">
          <span className="text-xs font-medium uppercase tracking-wider">Security Health</span>
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="text-2xl font-bold text-zinc-100 font-mono tracking-tight">
          100%
        </div>
        <div className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5">
          <span>SHA-256 hashed</span>
          <span aria-hidden="true">·</span>
          <span>Zero plaintext in DB</span>
        </div>
      </div>

      {/* Metric 3 */}
      <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4">
        <div className="flex items-center justify-between text-zinc-400 mb-2">
          <span className="text-xs font-medium uppercase tracking-wider">Requests Authenticated</span>
          <Activity className="w-4 h-4 text-sky-400" />
        </div>
        <div className="text-2xl font-bold text-zinc-100 font-mono tracking-tight">
          {totalRequests.toLocaleString()}
        </div>
        <div className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5">
          <span>Bearer token auth</span>
          <span aria-hidden="true">·</span>
          <span>Sub-ms lookups</span>
        </div>
      </div>

      {/* Metric 4 */}
      <div className="bg-zinc-900/60 border border-zinc-800/80 rounded-xl p-4">
        <div className="flex items-center justify-between text-zinc-400 mb-2">
          <span className="text-xs font-medium uppercase tracking-wider">Lifecycle Status</span>
          <Lock className="w-4 h-4 text-amber-400" />
        </div>
        <div className="text-2xl font-bold text-zinc-100 font-mono tracking-tight">
          {expiringSoonKeys.length > 0 ? (
            <span className="text-amber-400">{expiringSoonKeys.length} soon</span>
          ) : (
            <span className="text-zinc-200">Optimal</span>
          )}
        </div>
        <div className="text-xs text-zinc-500 mt-1 flex items-center gap-1.5">
          {expiringSoonKeys.length > 0 ? (
            <span>Action recommended</span>
          ) : (
            <span>No immediate expirations</span>
          )}
        </div>
      </div>
    </div>
  );
};
