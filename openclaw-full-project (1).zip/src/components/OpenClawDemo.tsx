import React, { useState, useRef, useEffect } from 'react';
import {
  OpenClawChannel,
  OpenClawMessage,
  AgentExecutionStep,
  WorkspaceFiles,
} from '../types/openclaw';
import { DEFAULT_WORKSPACE_FILES, DEMO_SCENARIOS, DemoScenario } from '../data/openclawDefaults';
import {
  Bot,
  Send,
  Terminal,
  FileCode,
  Brain,
  Zap,
  CheckCircle2,
  Clock,
  ChevronDown,
  ChevronRight,
  FolderTree,
  Cpu,
  Sparkles,
  RefreshCw,
  Copy,
  Check,
  Globe,
  MessageSquare,
  HardDrive,
  FileText,
  KeyRound,
  Download,
} from 'lucide-react';

interface OpenClawDemoProps {
  onOpenKeyVault: () => void;
  onOpenDownload: () => void;
  onToast: (title: string, message?: string) => void;
}

export const OpenClawDemo: React.FC<OpenClawDemoProps> = ({ onOpenKeyVault, onOpenDownload, onToast }) => {
  const [channel, setChannel] = useState<OpenClawChannel>('web');
  const [selectedModel, setSelectedModel] = useState<'gemini-flash' | 'gemini-pro'>('gemini-flash');
  const [inputPrompt, setInputPrompt] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [messages, setMessages] = useState<OpenClawMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'agent',
      channel: 'web',
      text: `Chào bạn! Mình là OpenClaw – trợ lý AI tự trị được tiếp sức bởi trí tuệ nhân tạo **Google Gemini AI**.

Với tư cách là một Autonomous Agent chạy trực tiếp trên máy tính của bạn, mình có thể:
- 🛠️ **Thực thi lệnh Shell:** Chạy kiểm tra hệ thống, quét thư mục và kiểm thử mã nguồn.
- 📁 **Đọc & Viết file:** Tự động tạo script, cập nhật dự án trực tiếp vào Workspace.
- 🧠 **Bộ nhớ dài hạn (Persistent Memory):** Tự động ghi lại ngữ cảnh và sở thích của bạn vào \`MEMORY.md\`.
- 🌐 **Đa kênh:** Nhận lệnh và phản hồi qua Web, Telegram, Discord hoặc WhatsApp.

Bạn có thể chọn một trong các kịch bản mẫu bên dưới hoặc gõ trực tiếp câu hỏi để mình hỗ trợ ngay nhé!`,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const [workspaceFiles, setWorkspaceFiles] = useState<WorkspaceFiles>(DEFAULT_WORKSPACE_FILES);
  const [activeFileTab, setActiveFileTab] = useState<string>('MEMORY.md');
  const [isEditingFile, setIsEditingFile] = useState(false);
  const [fileContentDraft, setFileContentDraft] = useState('');
  const [activeRightTab, setActiveRightTab] = useState<'workspace' | 'terminal' | 'architecture'>('workspace');
  const [terminalHistory, setTerminalHistory] = useState<string[]>([
    'OpenClaw Gateway v1.0.0 daemon started on 127.0.0.1:18789',
    'Loaded workspace from /workspace (SOUL.md, MEMORY.md, TOOLS.md)',
    'Ready for incoming channel events...',
  ]);
  const [terminalInput, setTerminalInput] = useState('');
  const [copiedKey, setCopiedKey] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isRunning]);

  useEffect(() => {
    setFileContentDraft(workspaceFiles[activeFileTab] || '');
  }, [activeFileTab, workspaceFiles]);

  const handleSelectScenario = (scenario: DemoScenario) => {
    setInputPrompt(scenario.prompt);
  };

  const handleRunAgent = async (promptToRun?: string) => {
    const text = (promptToRun || inputPrompt).trim();
    if (!text || isRunning) return;

    setInputPrompt('');

    // Add user message
    const userMsgId = `user_${Date.now()}`;
    const newMessages: OpenClawMessage[] = [
      ...messages,
      {
        id: userMsgId,
        sender: 'user',
        channel,
        text,
        timestamp: new Date().toLocaleTimeString(),
      },
    ];

    setMessages(newMessages);
    setIsRunning(true);

    // Initial agent placeholder message with live steps
    const agentMsgId = `agent_${Date.now()}`;
    const initialSteps: AgentExecutionStep[] = [
      {
        id: 'step-1',
        type: 'ingestion',
        title: `Gateway Ingestion (Channel: ${channel.toUpperCase()})`,
        detail: `Đã nhận sự kiện từ kênh ${channel}, kiểm tra quyền truy cập daemon 127.0.0.1:18789`,
        status: 'running',
        timestamp: new Date().toLocaleTimeString(),
      },
      {
        id: 'step-2',
        type: 'context',
        title: 'Tải Workspace (SOUL.md, MEMORY.md, TOOLS.md)',
        detail: 'Đọc bản sắc agent và các thông tin ghi nhớ trước đó',
        status: 'pending',
        timestamp: '',
      },
      {
        id: 'step-3',
        type: 'thinking',
        title: 'Suy luận & Lập kế hoạch (Gemini 3.8 Flash)',
        detail: 'Phân tích yêu cầu và xác định công cụ tự trị phù hợp',
        status: 'pending',
        timestamp: '',
      },
      {
        id: 'step-4',
        type: 'tool_call',
        title: 'Thực thi Công cụ Tự trị (Tool Execution)',
        detail: 'Chờ phân giải công cụ...',
        status: 'pending',
        timestamp: '',
      },
      {
        id: 'step-5',
        type: 'response',
        title: 'Tổng hợp & Phản hồi Kênh',
        detail: 'Hoàn tất vòng lặp và cập nhật trạng thái',
        status: 'pending',
        timestamp: '',
      },
    ];

    setMessages((prev) => [
      ...prev,
      {
        id: agentMsgId,
        sender: 'agent',
        channel,
        text: 'Đang xử lý vòng lặp agent...',
        timestamp: new Date().toLocaleTimeString(),
        steps: initialSteps,
      },
    ]);

    // Simulate step 1 completion
    await new Promise((r) => setTimeout(r, 600));
    updateAgentStep(agentMsgId, 'step-1', 'completed');
    updateAgentStep(agentMsgId, 'step-2', 'running');

    // Simulate step 2 completion
    await new Promise((r) => setTimeout(r, 600));
    updateAgentStep(agentMsgId, 'step-2', 'completed');
    updateAgentStep(agentMsgId, 'step-3', 'running');

    // Perform actual API or smart execution
    try {
      let responseText = '';
      let toolExecuted = '';
      let toolResult = '';
      let updatedFiles = { ...workspaceFiles };

      const res = await fetch('/api/agent/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          channel,
          model: selectedModel,
          soul: workspaceFiles['SOUL.md'],
          memory: workspaceFiles['MEMORY.md'],
          tools: workspaceFiles['TOOLS.md'],
        }),
      });

      const data = await res.json();

      // Check prompt intention
      const lower = text.toLowerCase();
      if (lower.includes('memory') || lower.includes('ghi nhớ') || lower.includes('lưu')) {
        toolExecuted = 'memory_save';
        const newFact = `- [${new Date().toLocaleDateString()}] Người dùng đã lưu ghi chú: "${text.slice(0, 80)}..."`;
        const newMemory = `${workspaceFiles['MEMORY.md']}\n${newFact}\n`;
        updatedFiles['MEMORY.md'] = newMemory;
        setWorkspaceFiles(updatedFiles);
        toolResult = `Đã cập nhật MEMORY.md thành công (+1 mục mới)`;
        setTerminalHistory((prev) => [
          ...prev,
          `$ openclaw memory add --fact "${text.slice(0, 40)}"`,
          `[SUCCESS] Appended to /workspace/MEMORY.md`,
        ]);
        responseText =
          data.text ||
          `Chào bạn! Mình đã xử lý yêu cầu và tự động ghi nhớ thông tin này vào bộ nhớ dài hạn **\`MEMORY.md\`** của OpenClaw.\n\n✨ **Nội dung vừa lưu:**\n> "${text}"\n\nKý ức này sẽ được tự động duy trì và nạp lại trong tất cả các phiên làm việc tiếp theo của bạn, giúp Agent luôn hiểu đúng ngữ cảnh và phong cách lập trình của bạn!`;
      } else if (lower.includes('file') || lower.includes('mã nguồn') || lower.includes('script') || lower.includes('keygen')) {
        toolExecuted = 'file_write';
        const scriptCode = `// Autogenerated by OpenClaw Autonomous Agent (Powered by Gemini)\nexport function generateToken(prefix = 'claw_') {\n  const rand = Math.random().toString(36).substring(2, 15);\n  return \`\${prefix}\${rand}\`;\n}\nconsole.log("Token generated:", generateToken());\n`;
        updatedFiles['src/keygen.js'] = scriptCode;
        setWorkspaceFiles(updatedFiles);
        setActiveFileTab('src/keygen.js');
        toolResult = `Created /workspace/src/keygen.js (164 bytes)`;
        setTerminalHistory((prev) => [
          ...prev,
          `$ touch src/keygen.js && cat << 'EOF' > src/keygen.js`,
          `[WRITE] /workspace/src/keygen.js written successfully`,
        ]);
        responseText =
          data.text ||
          `Chào bạn! Dựa trên phân tích bằng trí tuệ Google Gemini, mình đã sử dụng công cụ **\`file_write\`** để tạo cấu trúc và khởi tạo file mã nguồn mới cho bạn:\n\n- 📄 **File:** \`/workspace/src/keygen.js\`\n- 📦 **Nội dung:** Chứa hàm sinh token ngẫu nhiên chuẩn tiền tố an toàn.\n\nBạn có thể nhấp vào tab **Workspace** ở bảng bên phải để xem trực tiếp code hoặc chỉnh sửa theo ý muốn nhé!`;
      } else if (lower.includes('node') || lower.includes('kiểm tra') || lower.includes('ram') || lower.includes('hệ thống')) {
        toolExecuted = 'bash';
        toolResult = `node -v => v22.14.0 | RAM: 1.2GB / 4.0GB (28% used) | Gateway: OK`;
        setTerminalHistory((prev) => [
          ...prev,
          `$ node -v && free -m && openclaw gateway ping`,
          `v22.14.0`,
          `Mem: 4096 total, 1148 used, 2948 free`,
          `Gateway: 127.0.0.1:18789 is ALIVE (latency: 1.2ms)`,
        ]);
        responseText =
          data.text ||
          `Chào bạn! Dưới đây là báo cáo chẩn đoán hệ thống OpenClaw từ Gemini AI:\n\n- 🟢 **Node.js Environment:** Phiên bản \`v22.14.0\` (Rất mới và tối ưu cho Agent runtime)\n- ⚡ **OpenClaw Gateway:** Daemon \`127.0.0.1:18789\` phản hồi cực nhanh (1.2ms)\n- 💾 **Bộ nhớ RAM:** 1.2 GB / 4.0 GB (Sử dụng 28%, tài nguyên còn rất dồi dào)\n\nHệ thống đang ở trạng thái tối ưu, sẵn sàng thực thi các tác vụ tự trị tiếp theo của bạn!`;
      } else {
        toolExecuted = 'bash';
        toolResult = `Executed command inspection: status code 0`;
        responseText =
          data.text ||
          `Chào bạn! Với trí tuệ Google Gemini AI, mình đã tiếp nhận yêu cầu từ kênh **${channel.toUpperCase()}**.\n\nMình đã đối chiếu với nguyên tắc trong **\`SOUL.md\`**, kiểm tra bộ nhớ **\`MEMORY.md\`** và thực thi quy trình phân tích tự trị. Bạn có thể thử nghiệm thêm các kịch bản như ghi nhớ sở thích, tạo file script hoặc kiểm tra bảo mật API Key nhé!`;
      }

      // Step 3 completed
      updateAgentStep(agentMsgId, 'step-3', 'completed');
      updateAgentStep(agentMsgId, 'step-4', 'running', `Đang gọi tool: ${toolExecuted}`);

      await new Promise((r) => setTimeout(r, 600));
      updateAgentStep(agentMsgId, 'step-4', 'completed', toolResult);
      updateAgentStep(agentMsgId, 'step-5', 'running');

      await new Promise((r) => setTimeout(r, 400));
      updateAgentStep(agentMsgId, 'step-5', 'completed');

      // Final message update
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === agentMsgId
            ? {
                ...msg,
                text: responseText,
                toolCalls: [
                  {
                    tool: toolExecuted,
                    args: { prompt: text },
                    result: toolResult,
                  },
                ],
              }
            : msg
        )
      );

      onToast('OpenClaw đã thực thi xong!', `Hoàn tất tác vụ qua kênh ${channel.toUpperCase()}`);
    } catch (err: any) {
      updateAgentStep(agentMsgId, 'step-3', 'failed', err?.message);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === agentMsgId
            ? {
                ...msg,
                text: `Đã có lỗi xảy ra trong quá trình thực thi: ${err?.message}`,
              }
            : msg
        )
      );
    } finally {
      setIsRunning(false);
    }
  };

  const updateAgentStep = (
    msgId: string,
    stepId: string,
    status: 'pending' | 'running' | 'completed' | 'failed',
    detailOverride?: string
  ) => {
    setMessages((prev) =>
      prev.map((msg) => {
        if (msg.id !== msgId || !msg.steps) return msg;
        return {
          ...msg,
          steps: msg.steps.map((st) =>
            st.id === stepId
              ? {
                  ...st,
                  status,
                  detail: detailOverride || st.detail,
                  timestamp: status === 'completed' ? new Date().toLocaleTimeString() : st.timestamp,
                }
              : st
          ),
        };
      })
    );
  };

  const handleSaveFileDraft = () => {
    setWorkspaceFiles((prev) => ({
      ...prev,
      [activeFileTab]: fileContentDraft,
    }));
    setIsEditingFile(false);
    onToast(`Đã lưu ${activeFileTab}!`, 'Agent sẽ sử dụng cấu hình mới ngay lập tức.');
  };

  const handleRunTerminalCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = terminalInput.trim();
    if (!cmd) return;

    setTerminalInput('');
    const newHistory = [...terminalHistory, `$ ${cmd}`];

    if (cmd === 'clear') {
      setTerminalHistory([]);
      return;
    } else if (cmd === 'ls' || cmd === 'ls -la') {
      newHistory.push(Object.keys(workspaceFiles).join('   '));
    } else if (cmd.startsWith('cat ')) {
      const fileName = cmd.replace('cat ', '').trim();
      if (workspaceFiles[fileName]) {
        newHistory.push(workspaceFiles[fileName]);
      } else {
        newHistory.push(`cat: ${fileName}: No such file or directory`);
      }
    } else if (cmd.includes('openclaw')) {
      newHistory.push(
        'OpenClaw Core v1.0.0 (daemon active)\nGateway: 127.0.0.1:18789\nConnected channels: Web, Telegram, Discord\nModel: Gemini 3.8 Flash'
      );
    } else {
      newHistory.push(`[Executed]: ${cmd} (exit status: 0)`);
    }

    setTerminalHistory(newHistory);
  };

  const handleCopyGatewayToken = async () => {
    const token = 'sk_live_claw_demo_98f1a23e98124b';
    await navigator.clipboard.writeText(token);
    setCopiedKey(true);
    onToast('Đã sao chép Gateway Token!', '1-click copy: sẵn sàng dán vào cấu hình OpenClaw.');
    setTimeout(() => setCopiedKey(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner: Đơn giản & Dễ hiểu */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-center text-amber-400 shrink-0">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base font-bold text-zinc-100 tracking-tight">
                  OpenClaw Agent Playground (Demo Đơn Giản)
                </h2>
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/20 font-mono">
                  Autonomous Runtime
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
                Trải nghiệm trực quan cách OpenClaw hoạt động: Tự động tải bối cảnh từ <code className="text-amber-300 bg-zinc-950 px-1 py-0.5 rounded">SOUL.md</code>, lưu trữ trí nhớ vào <code className="text-amber-300 bg-zinc-950 px-1 py-0.5 rounded">MEMORY.md</code>, thực thi câu lệnh shell và kết nối đa kênh!
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={onOpenDownload}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-zinc-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-lg transition-colors shadow-sm"
              title="Tải gói Workspace .ZIP hoặc xem hướng dẫn cài đặt lên máy tính"
            >
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Tải về máy (.ZIP)</span>
            </button>

            <button
              onClick={handleCopyGatewayToken}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-200 bg-zinc-800 hover:bg-zinc-700 rounded-lg border border-zinc-700 transition-colors"
              title="Sao chép Token 1-Click"
            >
              {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
              <span>{copiedKey ? 'Đã sao chép!' : 'Copy Token'}</span>
            </button>
            <button
              onClick={onOpenKeyVault}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:text-zinc-100 bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/80 rounded-lg transition-colors"
            >
              <KeyRound className="w-3.5 h-3.5 text-amber-400" />
              <span>API Key</span>
            </button>
          </div>
        </div>

        {/* 1-Click Demo Scenarios (Kịch bản mẫu nhanh) */}
        <div className="mt-5 pt-4 border-t border-zinc-800/80">
          <div className="text-[11px] font-medium text-zinc-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Chọn kịch bản demo chạy thử ngay (1-Click):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {DEMO_SCENARIOS.map((sc) => (
              <div
                key={sc.id}
                onClick={() => handleSelectScenario(sc)}
                className="group p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 hover:border-amber-400/50 hover:bg-zinc-950 cursor-pointer transition-all text-left"
              >
                <div className="text-xs font-semibold text-zinc-200 group-hover:text-amber-300 transition-colors">
                  {sc.title}
                </div>
                <div className="text-[11px] text-zinc-500 mt-1 line-clamp-2 leading-relaxed">
                  {sc.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Workspace: 2-Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Channel Chat & Agent Execution Stream */}
        <div className="lg:col-span-7 flex flex-col bg-zinc-900/70 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl min-h-[580px]">
          {/* Channel Selector Header */}
          <div className="px-4 py-3 border-b border-zinc-800 bg-zinc-950/60 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-zinc-400 uppercase tracking-wider">Kênh giao tiếp:</span>
              <div className="flex items-center p-0.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs">
                {(['web', 'telegram', 'whatsapp', 'discord'] as OpenClawChannel[]).map((ch) => (
                  <button
                    key={ch}
                    onClick={() => setChannel(ch)}
                    className={`px-2.5 py-1 rounded font-medium capitalize transition-colors ${
                      channel === ch
                        ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {ch === 'web' ? '🌐 Web' : ch === 'telegram' ? '✈️ Telegram' : ch === 'whatsapp' ? '💬 WhatsApp' : '👾 Discord'}
                  </button>
                ))}
              </div>
            </div>

            {/* Model Switcher */}
            <div className="flex items-center gap-1.5">
              <span className="hidden md:inline text-xs text-zinc-500">Mô hình AI:</span>
              <div className="flex items-center p-0.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedModel('gemini-flash')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded font-medium text-[11px] transition-colors ${
                    selectedModel === 'gemini-flash'
                      ? 'bg-amber-400 text-zinc-950 font-semibold shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Gemini 3.1 Flash</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedModel('gemini-pro')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded font-medium text-[11px] transition-colors ${
                    selectedModel === 'gemini-pro'
                      ? 'bg-amber-400 text-zinc-950 font-semibold shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Brain className="w-3 h-3" />
                  <span>Gemini Pro</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-zinc-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[11px] text-zinc-300">Gateway 127.0.0.1:18789</span>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 max-h-[460px]">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1.5`}
                >
                  <div className="flex items-center gap-1.5 text-[10px] text-zinc-500 font-mono">
                    <span>{isUser ? 'YOU' : 'OPENCLAW AGENT'}</span>
                    {!isUser && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-amber-400 font-sans font-medium flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-amber-400" />
                          Google Gemini AI
                        </span>
                      </>
                    )}
                    <span aria-hidden="true">·</span>
                    <span className="capitalize">{msg.channel}</span>
                    <span aria-hidden="true">·</span>
                    <span>{msg.timestamp}</span>
                  </div>

                  <div
                    className={`p-3.5 rounded-2xl max-w-[90%] text-xs leading-relaxed ${
                      isUser
                        ? 'bg-amber-400 text-zinc-950 font-medium rounded-tr-none'
                        : 'bg-zinc-950 border border-zinc-800/80 text-zinc-200 rounded-tl-none shadow-sm'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{msg.text}</div>

                    {/* Step-by-step Agent Loop Visualization */}
                    {msg.steps && msg.steps.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-zinc-800/80 space-y-2">
                        <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Cpu className="w-3.5 h-3.5 text-amber-400" />
                          <span>Chuỗi thực thi tự trị (Agentic Loop):</span>
                        </div>
                        <div className="space-y-1.5 bg-zinc-900/60 p-2.5 rounded-xl border border-zinc-800/60">
                          {msg.steps.map((st) => (
                            <div key={st.id} className="flex items-start gap-2 text-[11px]">
                              {st.status === 'completed' ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                              ) : st.status === 'running' ? (
                                <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0 mt-0.5" />
                              ) : (
                                <Clock className="w-3.5 h-3.5 text-zinc-600 shrink-0 mt-0.5" />
                              )}
                              <div className="flex-1 min-w-0">
                                <div className="font-medium text-zinc-300">{st.title}</div>
                                {st.detail && (
                                  <div className="text-zinc-500 text-[10px] truncate">{st.detail}</div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Tool Call Output Pill */}
                    {msg.toolCalls && msg.toolCalls.length > 0 && (
                      <div className="mt-2.5 pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400 flex items-center gap-2">
                        <Terminal className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                        <span className="text-zinc-500">Tool:</span>
                        <span className="text-amber-300 font-bold">{msg.toolCalls[0].tool}</span>
                        <span className="text-zinc-600">→</span>
                        <span className="text-emerald-400 truncate">{msg.toolCalls[0].result}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Prompt Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleRunAgent();
            }}
            className="p-3 border-t border-zinc-800 bg-zinc-950/80"
          >
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                placeholder="Nhập yêu cầu cho OpenClaw (VD: Kiểm tra file, lưu sở thích, chạy bash)..."
                disabled={isRunning}
                className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
              <button
                type="submit"
                disabled={isRunning || !inputPrompt.trim()}
                className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl transition-all shadow-md disabled:opacity-50"
              >
                {isRunning ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Chạy</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column (5 cols): Workspace Inspector & Markdown-as-Config */}
        <div className="lg:col-span-5 flex flex-col bg-zinc-900/70 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
          {/* Sub tabs */}
          <div className="px-4 py-2.5 border-b border-zinc-800 bg-zinc-950/60 flex items-center justify-between">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setActiveRightTab('workspace')}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg transition-colors ${
                  activeRightTab === 'workspace'
                    ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <FolderTree className="w-3.5 h-3.5" />
                <span>Workspace</span>
              </button>
              <button
                onClick={() => setActiveRightTab('terminal')}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg transition-colors ${
                  activeRightTab === 'terminal'
                    ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Bash Sandbox</span>
              </button>
              <button
                onClick={() => setActiveRightTab('architecture')}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg transition-colors ${
                  activeRightTab === 'architecture'
                    ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Brain className="w-3.5 h-3.5" />
                <span>Kiến trúc</span>
              </button>
            </div>

            {activeRightTab === 'workspace' && (
              <div className="flex items-center gap-1 text-xs">
                {isEditingFile ? (
                  <button
                    onClick={handleSaveFileDraft}
                    className="px-2 py-0.5 bg-amber-400 text-zinc-950 font-semibold rounded text-[11px]"
                  >
                    Lưu file
                  </button>
                ) : (
                  <button
                    onClick={() => setIsEditingFile(true)}
                    className="text-zinc-400 hover:text-zinc-200 text-[11px]"
                  >
                    Chỉnh sửa
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Right tab content */}
          {activeRightTab === 'workspace' && (
            <div className="flex flex-col flex-1 min-h-[480px]">
              {/* File list pills */}
              <div className="flex items-center gap-1.5 p-2 bg-zinc-950/40 border-b border-zinc-800/80 overflow-x-auto">
                {Object.keys(workspaceFiles).map((fileName) => (
                  <button
                    key={fileName}
                    onClick={() => {
                      setActiveFileTab(fileName);
                      setIsEditingFile(false);
                    }}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono transition-colors whitespace-nowrap ${
                      activeFileTab === fileName
                        ? 'bg-zinc-800 text-amber-300 font-medium'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <FileText className="w-3 h-3 text-zinc-500" />
                    <span>{fileName}</span>
                  </button>
                ))}
              </div>

              {/* File Editor / Viewer */}
              <div className="flex-1 p-3 bg-zinc-950">
                {isEditingFile ? (
                  <textarea
                    value={fileContentDraft}
                    onChange={(e) => setFileContentDraft(e.target.value)}
                    className="w-full h-full min-h-[380px] bg-transparent font-mono text-xs text-zinc-200 focus:outline-none resize-none leading-relaxed"
                  />
                ) : (
                  <pre className="font-mono text-xs text-zinc-300 whitespace-pre-wrap leading-relaxed select-all overflow-y-auto max-h-[420px]">
                    {workspaceFiles[activeFileTab] || '// File empty'}
                  </pre>
                )}
              </div>

              <div className="px-3 py-2 border-t border-zinc-800/80 bg-zinc-950/40 text-[11px] text-zinc-500 flex items-center justify-between">
                <span>Đường dẫn: /workspace/{activeFileTab}</span>
                <span>Markdown-as-Config</span>
              </div>
            </div>
          )}

          {activeRightTab === 'terminal' && (
            <div className="flex flex-col flex-1 min-h-[480px] bg-zinc-950 font-mono text-xs">
              <div className="flex-1 p-3 overflow-y-auto space-y-1.5 text-zinc-300">
                {terminalHistory.map((line, idx) => (
                  <div
                    key={idx}
                    className={`${
                      line.startsWith('$')
                        ? 'text-amber-400 font-bold'
                        : line.startsWith('[SUCCESS]') || line.startsWith('[WRITE]')
                        ? 'text-emerald-400'
                        : 'text-zinc-400'
                    }`}
                  >
                    {line}
                  </div>
                ))}
              </div>

              <form onSubmit={handleRunTerminalCommand} className="p-2 border-t border-zinc-800 flex items-center gap-2">
                <span className="text-amber-400 font-bold pl-2">$</span>
                <input
                  type="text"
                  value={terminalInput}
                  onChange={(e) => setTerminalInput(e.target.value)}
                  placeholder="gõ lệnh: ls, cat MEMORY.md, openclaw status..."
                  className="flex-1 bg-transparent text-xs text-zinc-100 focus:outline-none"
                />
              </form>
            </div>
          )}

          {activeRightTab === 'architecture' && (
            <div className="p-4 space-y-4 text-xs text-zinc-300 overflow-y-auto max-h-[480px]">
              <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800 space-y-2">
                <div className="font-semibold text-zinc-100 flex items-center gap-1.5">
                  <Brain className="w-4 h-4 text-amber-400" />
                  <span>Cơ chế hoạt động của OpenClaw</span>
                </div>
                <p className="text-zinc-400 text-[11px] leading-relaxed">
                  OpenClaw là một framework Agent AI cục bộ (Local-first / Self-hosted), chạy bằng daemon Gateway đóng vai trò làm tổng đài WebSocket kết nối các ứng dụng nhắn tin vào Agent Runtime.
                </p>
              </div>

              <div className="space-y-2">
                <div className="font-semibold text-zinc-200">5 Thành phần cốt lõi:</div>
                <div className="space-y-1.5 text-[11px]">
                  <div className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                    <span className="font-semibold text-amber-300">1. Gateway Daemon:</span> Nhận tin nhắn từ Telegram, Discord, WhatsApp, Web.
                  </div>
                  <div className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                    <span className="font-semibold text-amber-300">2. Markdown-as-Config:</span> Nhân cách và bộ nhớ được lưu bằng Markdown thuần (SOUL.md, MEMORY.md).
                  </div>
                  <div className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                    <span className="font-semibold text-amber-300">3. Autonomous Agent Loop:</span> Ingestion $\rightarrow$ Thinking $\rightarrow$ Tool Call $\rightarrow$ Output.
                  </div>
                  <div className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                    <span className="font-semibold text-amber-300">4. Tool & MCP Integration:</span> Quyền chạy bash, ghi file, duyệt web.
                  </div>
                  <div className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                    <span className="font-semibold text-amber-300">5. Multi-Agent Routing:</span> Phân nhánh sub-agents xử lý song song.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
