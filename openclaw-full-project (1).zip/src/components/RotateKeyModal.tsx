import React, { useState } from 'react';
import { ApiKey } from '../types/apiKey';
import { generateCryptographicKey } from '../utils/crypto';
import { RefreshCw, X, ShieldAlert, Check } from 'lucide-react';

interface RotateKeyModalProps {
  isOpen: boolean;
  apiKey: ApiKey | null;
  onClose: () => void;
  onKeyRotated: (oldKeyId: string, updatedKey: ApiKey, newRawKey: string) => void;
}

export const RotateKeyModal: React.FC<RotateKeyModalProps> = ({
  isOpen,
  apiKey,
  onClose,
  onKeyRotated,
}) => {
  const [keepGracePeriod, setKeepGracePeriod] = useState(true);
  const [isRotating, setIsRotating] = useState(false);

  if (!isOpen || !apiKey) return null;

  const handleRotate = async () => {
    setIsRotating(true);
    try {
      const result = await generateCryptographicKey({
        prefix: apiKey.keyPrefix,
        byteEntropy: 24,
        includeChecksum: true,
      });

      const updatedKey: ApiKey = {
        ...apiKey,
        maskedKey: result.maskedKey,
        hash: result.hash,
        tail: result.tail,
        createdAt: new Date().toISOString(),
        rotationGracePeriodUntil: keepGracePeriod
          ? new Date(Date.now() + 24 * 3600000).toISOString()
          : null,
      };

      onKeyRotated(apiKey.id, updatedKey, result.fullKey);
      onClose();
    } finally {
      setIsRotating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden p-6 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-zinc-100">Rotate API Key</h3>
          </div>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-200 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="text-xs text-zinc-300 space-y-2">
          <p>
            Rotating <strong className="text-amber-300">{apiKey.name}</strong> ({apiKey.maskedKey}) will create a new cryptographically secure secret.
          </p>
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2 text-zinc-400 text-[11px]">
            <label className="flex items-start gap-2.5 cursor-pointer text-zinc-200">
              <input
                type="checkbox"
                checked={keepGracePeriod}
                onChange={(e) => setKeepGracePeriod(e.target.checked)}
                className="mt-0.5 rounded border-zinc-700 bg-zinc-900 text-amber-500 focus:ring-0"
              />
              <span>
                <strong>24-Hour Zero-Downtime Grace Period:</strong> Keep the previous key active for 24 hours so you can update environment variables across backend pods without service disruption.
              </span>
            </label>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleRotate}
            disabled={isRotating}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
            <span>{isRotating ? 'Rotating...' : 'Generate New Key'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
