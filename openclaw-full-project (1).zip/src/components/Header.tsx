import React from 'react';
import { KeyRound, Plus, Zap, ShieldCheck, Terminal, BookOpen, Download } from 'lucide-react';

interface HeaderProps {
  onOpenCreateModal: () => void;
  onQuickGenerate: () => void;
  onOpenSecurityGuide: () => void;
  onOpenDownload: () => void;
  activeTab: 'keys' | 'sandbox';
  setActiveTab: (tab: 'keys' | 'sandbox') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreateModal,
  onQuickGenerate,
  onOpenSecurityGuide,
  onOpenDownload,
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-zinc-900 border border-zinc-700/80 flex items-center justify-center text-amber-400 shadow-sm">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-zinc-100 tracking-tight text-base">API Key Studio</span>
              <span className="text-xs text-zinc-500 font-mono">v2.4</span>
            </div>
            <div className="text-xs text-zinc-400">
              Cryptographic key management & sandbox
            </div>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="hidden sm:flex items-center bg-zinc-900/90 border border-zinc-800 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('keys')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
              activeTab === 'keys'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Key Vault</span>
          </button>
          <button
            onClick={() => setActiveTab('sandbox')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
              activeTab === 'sandbox'
                ? 'bg-zinc-800 text-zinc-100 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>API Sandbox</span>
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenSecurityGuide}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:text-zinc-100 hover:bg-zinc-900 rounded-lg border border-zinc-800 transition-colors"
            title="API Key security, hashing & Gemini API guide"
          >
            <BookOpen className="w-3.5 h-3.5 text-zinc-400" />
            <span>Security & Guide</span>
          </button>

          <button
            onClick={onOpenDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:text-amber-200 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 rounded-lg transition-colors"
            title="Tải gói Workspace .ZIP hoặc hướng dẫn cài đặt lên máy tính"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Tải về máy</span>
          </button>

          <button
            onClick={onQuickGenerate}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:text-zinc-100 hover:bg-zinc-900 rounded-lg border border-zinc-800 transition-colors"
            title="Instantly generate and copy a cryptographically secure key"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Quick Key</span>
          </button>

          <button
            onClick={onOpenCreateModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-zinc-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-lg shadow-sm transition-all font-semibold"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Create API Key</span>
          </button>
        </div>
      </div>
    </header>
  );
};
