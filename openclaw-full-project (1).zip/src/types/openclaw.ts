export type OpenClawChannel = 'web' | 'telegram' | 'whatsapp' | 'discord';

export type AgentStepStatus = 'pending' | 'running' | 'completed' | 'failed';

export interface AgentExecutionStep {
  id: string;
  type: 'ingestion' | 'context' | 'thinking' | 'tool_call' | 'tool_result' | 'memory_update' | 'response';
  title: string;
  detail?: string;
  status: AgentStepStatus;
  timestamp: string;
  data?: any;
}

export interface OpenClawMessage {
  id: string;
  sender: 'user' | 'agent' | 'system';
  channel: OpenClawChannel;
  text: string;
  timestamp: string;
  steps?: AgentExecutionStep[];
  toolCalls?: {
    tool: string;
    args: any;
    result: string;
  }[];
}

export interface WorkspaceFiles {
  'SOUL.md': string;
  'MEMORY.md': string;
  'TOOLS.md': string;
  'USER.md': string;
  'openclaw.json': string;
  [key: string]: string;
}
