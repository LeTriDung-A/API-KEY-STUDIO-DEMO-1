export type KeyEnvironment = 'production' | 'staging' | 'development';

export type KeyStatus = 'active' | 'expiring_soon' | 'expired' | 'revoked';

export interface ScopeDefinition {
  id: string;
  name: string;
  description: string;
  category: 'Read' | 'Write' | 'Admin' | 'Billing' | 'Webhooks';
}

export interface ApiKey {
  id: string;
  name: string;
  keyPrefix: string; // e.g. "sk_live_"
  maskedKey: string; // e.g. "sk_live_9f2a••••••••••••••b81c"
  hash: string; // SHA-256 hash of the full key (hex string)
  tail: string; // Last 4 chars for identification
  environment: KeyEnvironment;
  scopes: string[]; // List of scope IDs
  createdAt: string; // ISO date
  expiresAt: string | null; // ISO date or null for never
  lastUsedAt: string | null; // ISO date or null
  rateLimit: {
    requestsPerMinute: number;
    requestsPerDay: number;
  };
  allowedIps: string[]; // CIDR or IP list, empty means any
  status: KeyStatus;
  requestCount: number;
  rotationGracePeriodUntil?: string | null; // When rotating, old key remains active until this date
}

export interface ApiEndpoint {
  id: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  requiredScopes: string[];
  mockResponse: (key: ApiKey | null, requestBody?: any) => {
    status: number;
    data: any;
    headers?: Record<string, string>;
  };
}

export interface TestExecutionResult {
  endpoint: string;
  method: string;
  status: number;
  statusText: string;
  durationMs: number;
  responseHeaders: Record<string, string>;
  responseBody: any;
  timestamp: string;
  sentKey: string;
}
