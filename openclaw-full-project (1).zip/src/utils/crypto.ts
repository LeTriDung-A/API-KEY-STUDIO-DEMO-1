import { ScopeDefinition } from '../types/apiKey';

const BASE62_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

export const AVAILABLE_SCOPES: ScopeDefinition[] = [
  { id: 'read:users', name: 'Read Users', description: 'Retrieve user profiles and identities', category: 'Read' },
  { id: 'read:data', name: 'Read Records', description: 'Read queryable databases and documents', category: 'Read' },
  { id: 'read:analytics', name: 'Read Analytics', description: 'Access metrics, event streams and audit trails', category: 'Read' },
  { id: 'write:records', name: 'Write Records', description: 'Create and update resource records', category: 'Write' },
  { id: 'write:files', name: 'Upload Files', description: 'Upload storage assets and file blobs', category: 'Write' },
  { id: 'delete:records', name: 'Delete Records', description: 'Soft-delete or purge customer data', category: 'Write' },
  { id: 'billing:manage', name: 'Manage Billing', description: 'Access subscriptions, payment methods and invoices', category: 'Billing' },
  { id: 'webhooks:listen', name: 'Receive Webhooks', description: 'Ingest inbound webhook deliveries', category: 'Webhooks' },
  { id: 'webhooks:trigger', name: 'Trigger Webhooks', description: 'Fire outbound webhook event notifications', category: 'Webhooks' },
  { id: 'admin:all', name: 'Full Admin', description: 'Bypass scope validation with superuser privileges', category: 'Admin' },
];

/**
 * Computes standard CRC32 checksum of a string
 */
function crc32(str: string): number {
  let crc = 0 ^ (-1);
  for (let i = 0; i < str.length; i++) {
    crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ str.charCodeAt(i)) & 0xff];
  }
  return (crc ^ (-1)) >>> 0;
}

const CRC32_TABLE = (() => {
  let c: number;
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c;
  }
  return table;
})();

/**
 * Computes SHA-256 hash using native Web Crypto API
 */
export async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export interface KeyGenerationOptions {
  prefix?: string;
  byteEntropy?: number; // default 24 bytes = 192 bits
  includeChecksum?: boolean; // GitHub / Stripe style checksum suffix for secret scanning
}

export interface GeneratedKeyResult {
  fullKey: string;
  maskedKey: string;
  tail: string;
  hash: string;
  entropyBits: number;
}

export async function generateCryptographicKey(options: KeyGenerationOptions = {}): Promise<GeneratedKeyResult> {
  const {
    prefix = 'sk_live_',
    byteEntropy = 24,
    includeChecksum = true,
  } = options;

  // Generate random bytes using cryptographically secure PRNG
  const randomBytes = new Uint8Array(byteEntropy);
  crypto.getRandomValues(randomBytes);

  // Convert to Base62
  let secretBody = '';
  for (let i = 0; i < randomBytes.length; i++) {
    secretBody += BASE62_CHARS[randomBytes[i] % BASE62_CHARS.length];
  }

  let finalKey = `${prefix}${secretBody}`;

  if (includeChecksum) {
    const checksumNum = crc32(secretBody);
    // Convert 32-bit checksum to 6-char base62
    let checksumStr = '';
    let temp = checksumNum;
    for (let i = 0; i < 6; i++) {
      checksumStr += BASE62_CHARS[temp % BASE62_CHARS.length];
      temp = Math.floor(temp / BASE62_CHARS.length);
    }
    finalKey = `${finalKey}_${checksumStr}`;
  }

  const hash = await sha256(finalKey);
  const tail = finalKey.slice(-4);
  const maskedKey = `${prefix}${finalKey.slice(prefix.length, prefix.length + 4)}••••••••••••••••${tail}`;
  const entropyBits = byteEntropy * 8;

  return {
    fullKey: finalKey,
    maskedKey,
    tail,
    hash,
    entropyBits,
  };
}

/**
 * Validates key format and secret scanner checksum
 */
export function verifyKeyChecksum(key: string): { validFormat: boolean; checksumValid: boolean } {
  const parts = key.split('_');
  if (parts.length < 3) {
    return { validFormat: false, checksumValid: false };
  }
  
  // Last segment may be checksum
  const checksumCandidate = parts[parts.length - 1];
  if (checksumCandidate.length === 6) {
    // Reconstruct body
    const bodyParts = parts.slice(2, -1);
    const body = bodyParts.join('_');
    if (body.length > 0) {
      const expectedNum = crc32(body);
      let calculatedStr = '';
      let temp = expectedNum;
      for (let i = 0; i < 6; i++) {
        calculatedStr += BASE62_CHARS[temp % BASE62_CHARS.length];
        temp = Math.floor(temp / BASE62_CHARS.length);
      }
      return {
        validFormat: true,
        checksumValid: calculatedStr === checksumCandidate,
      };
    }
  }

  return { validFormat: true, checksumValid: false };
}
