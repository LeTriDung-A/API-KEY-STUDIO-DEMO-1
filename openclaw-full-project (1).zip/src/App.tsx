import React, { useState, useEffect } from 'react';
import { ApiKey } from './types/apiKey';
import { INITIAL_MOCK_KEYS } from './data/mockKeys';
import { Header } from './components/Header';
import { KeyStats } from './components/KeyStats';
import { QuickKeyBar } from './components/QuickKeyBar';
import { KeysTable } from './components/KeysTable';
import { CreateKeyModal } from './components/CreateKeyModal';
import { KeyRevealModal } from './components/KeyRevealModal';
import { RotateKeyModal } from './components/RotateKeyModal';
import { KeyDetailsDrawer } from './components/KeyDetailsDrawer';
import { CodeSnippetsModal } from './components/CodeSnippetsModal';
import { ApiSandbox } from './components/ApiSandbox';
import { OpenClawDemo } from './components/OpenClawDemo';
import { SecurityGuideModal } from './components/SecurityGuideModal';
import { DownloadModal } from './components/DownloadModal';
import { DEFAULT_WORKSPACE_FILES } from './data/openclawDefaults';
import { ToastContainer, ToastMessage } from './components/Toast';
import { generateCryptographicKey } from './utils/crypto';
import { Bot, ShieldCheck, Terminal, Sparkles, KeyRound, Download } from 'lucide-react';

const STORAGE_KEY = 'api_key_studio_records_v2';

export default function App() {
  const [keys, setKeys] = useState<ApiKey[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    return INITIAL_MOCK_KEYS;
  });

  const [activeTab, setActiveTab] = useState<'openclaw' | 'keys' | 'sandbox'>('openclaw');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isRevealModalOpen, setIsRevealModalOpen] = useState(false);
  const [newlyCreatedKey, setNewlyCreatedKey] = useState<{ apiKey: ApiKey; rawKey: string } | null>(null);

  const [rotatingKey, setRotatingKey] = useState<ApiKey | null>(null);
  const [inspectingKey, setInspectingKey] = useState<ApiKey | null>(null);
  const [codeSnippetKey, setCodeSnippetKey] = useState<ApiKey | null>(null);
  const [isSecurityGuideOpen, setIsSecurityGuideOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [sandboxSelectedKeyId, setSandboxSelectedKeyId] = useState<string | undefined>(undefined);

  // Sync with localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(keys));
    } catch {
      // ignore
    }
  }, [keys]);

  const addToast = (title: string, message?: string, type: 'success' | 'warning' | 'error' | 'info' = 'success') => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // 1-Click Quick Generation
  const handleQuickGenerate = async () => {
    try {
      const generated = await generateCryptographicKey({
        prefix: 'sk_live_',
        byteEntropy: 24,
        includeChecksum: true,
      });

      const newKey: ApiKey = {
        id: `key_${Math.random().toString(36).substring(2, 10)}`,
        name: `Quick Production Key #${keys.length + 1}`,
        keyPrefix: 'sk_live_',
        maskedKey: generated.maskedKey,
        hash: generated.hash,
        tail: generated.tail,
        environment: 'production',
        scopes: ['read:users', 'read:data', 'write:records'],
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 60 * 86400000).toISOString(),
        lastUsedAt: null,
        rateLimit: { requestsPerMinute: 120, requestsPerDay: 20000 },
        allowedIps: [],
        status: 'active',
        requestCount: 0,
      };

      setKeys((prev) => [newKey, ...prev]);

      // Direct 1-click clipboard copy
      try {
        await navigator.clipboard.writeText(generated.fullKey);
      } catch {
        const input = document.createElement('textarea');
        input.value = generated.fullKey;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }

      addToast(
        'Đã tạo & Sao chép API Key (1-Click)!',
        `Key ${generated.maskedKey} đã được sao chép vào clipboard của bạn.`
      );
    } catch (err: any) {
      addToast('Lỗi tạo key', err?.message, 'error');
    }
  };

  const handleKeyCreatedFromModal = (newApiKey: ApiKey, rawPlaintextKey: string) => {
    setKeys((prev) => [newApiKey, ...prev]);
    setNewlyCreatedKey({ apiKey: newApiKey, rawKey: rawPlaintextKey });
    setIsRevealModalOpen(true);
    addToast('API Key đã được khởi tạo!', 'Hãy sao chép secret key trước khi đóng hộp thoại.');
  };

  const handleKeyRotated = (oldKeyId: string, updatedKey: ApiKey, newRawKey: string) => {
    setKeys((prev) => prev.map((k) => (k.id === oldKeyId ? updatedKey : k)));
    setNewlyCreatedKey({ apiKey: updatedKey, rawKey: newRawKey });
    setIsRevealModalOpen(true);
    addToast(
      'Đã xoay vòng Key (Rotated)!',
      'Đã tạo secret key mới và áp dụng thời gian ân hạn không gián đoạn.'
    );
  };

  const handleRevokeKey = (keyId: string) => {
    setKeys((prev) =>
      prev.map((k) => (k.id === keyId ? { ...k, status: 'revoked' as const } : k))
    );
    addToast('Đã thu hồi API Key', 'Key này sẽ ngay lập tức bị từ chối mọi quyền truy cập.', 'warning');
  };

  const handleDeleteKey = (keyId: string) => {
    setKeys((prev) => prev.filter((k) => k.id !== keyId));
    addToast('Đã xóa API Key khỏi cơ sở dữ liệu', undefined, 'info');
  };

  const handleRecordSandboxRequest = (keyId: string) => {
    setKeys((prev) =>
      prev.map((k) =>
        k.id === keyId
          ? {
              ...k,
              requestCount: k.requestCount + 1,
              lastUsedAt: new Date().toISOString(),
            }
          : k
      )
    );
  };

  const handleCopySingleKey = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      addToast('Đã sao chép token!', text);
    } catch {
      // fallback
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-400 selection:text-zinc-950">
      {/* Top Navigation */}
      <Header
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
        onQuickGenerate={handleQuickGenerate}
        onOpenSecurityGuide={() => setIsSecurityGuideOpen(true)}
        onOpenDownload={() => setIsDownloadModalOpen(true)}
        activeTab={activeTab === 'openclaw' ? 'keys' : (activeTab as any)}
        setActiveTab={(t) => setActiveTab(t)}
      />

      {/* Primary Tab Switcher Bar */}
      <div className="bg-zinc-950/90 border-b border-zinc-800/80 sticky top-16 z-20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 py-2.5 overflow-x-auto">
            <button
              onClick={() => setActiveTab('openclaw')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'openclaw'
                  ? 'bg-amber-400 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>Demo Thử OpenClaw (Agent)</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${activeTab === 'openclaw' ? 'bg-amber-500/30 text-zinc-950' : 'bg-zinc-800 text-zinc-400'}`}>
                Mới
              </span>
            </button>

            <button
              onClick={() => setActiveTab('keys')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'keys'
                  ? 'bg-amber-400 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>API Key Vault & Quản Lý</span>
              <span className="text-[10px] text-zinc-400 font-mono">({keys.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('sandbox')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'sandbox'
                  ? 'bg-amber-400 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>API Sandbox (Test Endpoint)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'openclaw' && (
          <OpenClawDemo
            onOpenKeyVault={() => setActiveTab('keys')}
            onOpenDownload={() => setIsDownloadModalOpen(true)}
            onToast={(t, m) => addToast(t, m)}
          />
        )}

        {activeTab === 'keys' && (
          <div>
            {/* 1-Click Generator Bar (One Copy) */}
            <QuickKeyBar
              onAddKey={(newKey, plaintext) => {
                setKeys((prev) => [newKey, ...prev]);
              }}
              onToast={(t, m) => addToast(t, m)}
            />

            {/* Health & Metrics */}
            <KeyStats keys={keys} onOpenCreate={() => setIsCreateModalOpen(true)} />

            {/* Keys Management Table */}
            <KeysTable
              keys={keys}
              onCopyKey={handleCopySingleKey}
              onOpenRotateModal={(k) => setRotatingKey(k)}
              onRevokeKey={handleRevokeKey}
              onDeleteKey={handleDeleteKey}
              onOpenDetails={(k) => setInspectingKey(k)}
              onOpenCodeSnippets={(k) => setCodeSnippetKey(k)}
              onTestInSandbox={(k) => {
                setSandboxSelectedKeyId(k.id);
                setActiveTab('sandbox');
              }}
              onOpenCreate={() => setIsCreateModalOpen(true)}
            />
          </div>
        )}

        {activeTab === 'sandbox' && (
          <ApiSandbox
            keys={keys}
            selectedKeyId={sandboxSelectedKeyId}
            onRecordRequest={handleRecordSandboxRequest}
            onToast={(t, m) => addToast(t, m)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-zinc-950/60 py-4 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span>OpenClaw Runtime & API Key Studio</span>
            <span aria-hidden="true">·</span>
            <span>Cryptographic CSPRNG SHA-256</span>
            <span aria-hidden="true">·</span>
            <span>Local Autonomous Daemon</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSecurityGuideOpen(true)}
              className="hover:text-zinc-300 transition-colors"
            >
              Hướng dẫn & Kiến trúc
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setActiveTab('openclaw')}
              className="text-amber-400 hover:text-amber-300 transition-colors"
            >
              Demo OpenClaw
            </button>
          </div>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <CreateKeyModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onKeyCreated={handleKeyCreatedFromModal}
      />

      {newlyCreatedKey && (
        <KeyRevealModal
          isOpen={isRevealModalOpen}
          apiKey={newlyCreatedKey.apiKey}
          rawKey={newlyCreatedKey.rawKey}
          onClose={() => setIsRevealModalOpen(false)}
          onCopySuccess={() =>
            addToast('Đã sao chép Secret Key vào Clipboard!', 'Lưu ý: Không thể xem lại sau khi đóng.')
          }
        />
      )}

      <RotateKeyModal
        isOpen={!!rotatingKey}
        apiKey={rotatingKey}
        onClose={() => setRotatingKey(null)}
        onKeyRotated={handleKeyRotated}
      />

      <KeyDetailsDrawer
        apiKey={inspectingKey}
        onClose={() => setInspectingKey(null)}
        onTestKey={(k) => {
          setSandboxSelectedKeyId(k.id);
          setActiveTab('sandbox');
        }}
      />

      <CodeSnippetsModal
        isOpen={!!codeSnippetKey}
        apiKey={codeSnippetKey}
        onClose={() => setCodeSnippetKey(null)}
        onToast={(t) => addToast(t)}
      />

      <SecurityGuideModal
        isOpen={isSecurityGuideOpen}
        onClose={() => setIsSecurityGuideOpen(false)}
      />

      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        workspaceFiles={DEFAULT_WORKSPACE_FILES}
        activeKeyToken={keys[0]?.maskedKey}
        onToast={(t, m) => addToast(t, m)}
      />

      {/* Toast notifications */}
      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}
